import inspect
import pickle
from copy import deepcopy
from typing import Any, Dict, List, Optional, Union

import numpy as np
from gymnasium import spaces

from stable_baselines3.common import utils
from stable_baselines3.common.preprocessing import is_image_space
from stable_baselines3.common.running_mean_std import RunningMeanStd
from stable_baselines3.common.vec_env.base_vec_env import VecEnv, VecEnvStepReturn, VecEnvWrapper


class VecNormalize(VecEnvWrapper):
    """
    A moving average, normalizing wrapper for vectorized environment.
    has support for saving/loading moving average,

    :param venv: the vectorized environment to wrap
    :param training: Whether to update or not the moving average
    :param norm_obs: Whether to normalize observation or not (default: True)
    :param norm_reward: Whether to normalize rewards or not (default: True)
    :param clip_obs: Max absolute value for observation
    :param clip_reward: Max value absolute for discounted reward
    :param gamma: discount factor
    :param epsilon: To avoid division by zero
    :param norm_obs_keys: Which keys from observation dict to normalize.
        If not specified, all keys will be normalized.
    """

    obs_spaces: Dict[str, spaces.Space]
    old_obs: Union[np.ndarray, Dict[str, np.ndarray]]

    def __init__(
        self,
        venv: VecEnv,
        training: bool = True,
        norm_obs: bool = True,
        norm_reward: bool = True,
        clip_obs: float = 10.0,
        clip_reward: float = 10.0,
        gamma: float = 0.99,
        epsilon: float = 1e-8,
        norm_obs_keys: Optional[List[str]] = None,
    ):
        VecEnvWrapper.__init__(self, venv)

        self.norm_obs = norm_obs
        self.norm_obs_keys = norm_obs_keys
        # Check observation spaces
        if self.norm_obs:
            # Note: mypy doesn't take into account the sanity checks, which lead to several type: ignore...
            self._sanity_checks()

            if isinstance(self.observation_space, spaces.Dict):
                self.obs_spaces = self.observation_space.spaces
                self.obs_rms = {key: RunningMeanStd(shape=self.obs_spaces[key].shape) for key in self.norm_obs_keys}  # type: ignore[arg-type, union-attr]
                # Update observation space when using image
                # See explanation below and GH #1214
                for key in self.obs_rms.keys():
                    if is_image_space(self.obs_spaces[key]):
                        self.observation_space.spaces[key] = spaces.Box(
                            low=-clip_obs,
                            high=clip_obs,
                            shape=self.obs_spaces[key].shape,
                            dtype=np.float32,
                        )

            else:
                self.obs_rms = RunningMeanStd(shape=self.observation_space.shape)  # type: ignore[assignment, arg-type]
                # Update observation space when using image
                # See GH #1214
                # This is to raise proper error when
                # VecNormalize is used with an image-like input and
                # normalize_images=True.
                # For correctness, we should also update the bounds
                # in other cases but this will cause backward-incompatible change
                # and break already saved policies.
                if is_image_space(self.observation_space):
                    self.observation_space = spaces.Box(
                        low=-clip_obs,
                        high=clip_obs,
                        shape=self.observation_space.shape,
                        dtype=np.float32,
                    )

        self.ret_rms = RunningMeanStd(shape=())
        self.clip_obs = clip_obs
        self.clip_reward = clip_reward
        # Returns: discounted rewards
        self.returns = np.zeros(self.num_envs)
        self.gamma = gamma
        self.epsilon = epsilon
        self.training = training
        self.norm_obs = norm_obs
        self.norm_reward = norm_reward
        self.old_reward = np.array([])

    def _sanity_checks(self) -> None:
        """
        Check the observations that are going to be normalized are of the correct type (spaces.Box).
        """
        if isinstance(self.observation_space, spaces.Dict):
            # By default, we normalize all keys
            if self.norm_obs_keys is None:
                self.norm_obs_keys = list(self.observation_space.spaces.keys())
            # Check that all keys are of type Box
            for obs_key in self.norm_obs_keys:
                if not isinstance(self.observation_space.spaces[obs_key], spaces.Box):
                    raise ValueError(
                        f"VecNormalize only supports `gym.spaces.Box` observation spaces but {obs_key} "
                        f"is of type {self.observation_space.spaces[obs_key]}. "
                        "You should probably explicitely pass the observation keys "
                        " that should be normalized via the `norm_obs_keys` parameter."
                    )

        elif isinstance(self.observation_space, spaces.Box):
            if self.norm_obs_keys is not None:
                raise ValueError("`norm_obs_keys` param is applicable only with `gym.spaces.Dict` observation spaces")

        else:
            raise ValueError(
                "VecNormalize only supports `gym.spaces.Box` and `gym.spaces.Dict` observation spaces, "
                f"not {self.observation_space}"
            )

    def __getstate__(self) -> Dict[str, Any]:
        """
        Gets state for pickling.

        Excludes self.venv, as in general VecEnv's may not be pickleable."""
        state = self.__dict__.copy()
        # these attributes are not pickleable
        del state["venv"]
        del state["class_attributes"]
        # these attributes depend on the above and so we would prefer not to pickle
        del state["returns"]
        return state

    def __setstate__(self, state: Dict[str, Any]) -> None:
        """
        Restores pickled state.

        User must call set_venv() after unpickling before using.

        :param state:"""
        # Backward compatibility
        if "norm_obs_keys" not in state and isinstance(state["observation_space"], spaces.Dict):
            state["norm_obs_keys"] = list(state["observation_space"].spaces.keys())
        self.__dict__.update(state)
        assert "venv" not in state
        self.venv = None  # type: ignore[assignment]

    def set_venv(self, venv: VecEnv) -> None:
        """
        Sets the vector environment to wrap to venv.

        Also sets attributes derived from this such as `num_env`.

        :param venv:
        """
        if self.venv is not None:
            raise ValueError("Trying to set venv of already initialized VecNormalize wrapper.")
        self.venv = venv
        self.num_envs = venv.num_envs
        self.class_attributes = dict(inspect.getmembers(self.__class__))
        self.render_mode = venv.render_mode

        # Check that the observation_space shape match
        utils.check_shape_equal(self.observation_space, venv.observation_space)
        self.returns = np.zeros(self.num_envs)

    def step_wait(self) -> VecEnvStepReturn:
        """
        Apply sequence of actions to sequence of environments
        actions -> (observations, rewards, dones)

        where ``dones`` is a boolean vector indicating whether each element is new.
        """
        obs, rewards, dones, infos = self.venv.step_wait()
        assert isinstance(obs, (np.ndarray, dict))  # for mypy
        self.old_obs = obs
        self.old_reward = rewards

        if self.training and self.norm_obs:
            if isinstance(obs, dict) and isinstance(self.obs_rms, dict):
                for key in self.obs_rms.keys():
                    self.obs_rms[key].update(obs[key])
            else:
                self.obs_rms.update(obs)

        obs = self.normalize_obs(obs)

        if self.training:
            self._update_reward(rewards)
        rewards = self.normalize_reward(rewards)

        # Normalize the terminal observations
        for idx, done in enumerate(dones):
            if not done:
                continue
            if "terminal_observation" in infos[idx]:
                infos[idx]["terminal_observation"] = self.normalize_obs(infos[idx]["terminal_observation"])

        self.returns[dones] = 0
        return obs, rewards, dones, infos

    def _update_reward(self, reward: np.ndarray) -> None:
        """Update reward normalization statistics."""
        self.returns = self.returns * self.gamma + reward
        self.ret_rms.update(self.returns)

    def _normalize_obs(self, obs: np.ndarray, obs_rms: RunningMeanStd) -> np.ndarray:
        """
        Helper to normalize observation.
        :param obs:
        :param obs_rms: associated statistics
        :return: normalized observation
        """
        return np.clip((obs - obs_rms.mean) / np.sqrt(obs_rms.var + self.epsilon), -self.clip_obs, self.clip_obs)

    def _unnormalize_obs(self, obs: np.ndarray, obs_rms: RunningMeanStd) -> np.ndarray:
        """
        Helper to unnormalize observation.
        :param obs:
        :param obs_rms: associated statistics
        :return: unnormalized observation
        """
        return (obs * np.sqrt(obs_rms.var + self.epsilon)) + obs_rms.mean

    def normalize_obs(self, obs: Union[np.ndarray, Dict[str, np.ndarray]]) -> Union[np.ndarray, Dict[str, np.ndarray]]:
        """
        Normalize observations using this VecNormalize's observations statistics.
        Calling this method does not update statistics.
        """
        # Avoid modifying by reference the original object
        obs_ = deepcopy(obs)
        if self.norm_obs:
            if isinstance(obs, dict) and isinstance(self.obs_rms, dict):
                assert self.norm_obs_keys is not None
                # Only normalize the specified keys
                for key in self.norm_obs_keys:
                    obs_[key] = self._normalize_obs(obs[key], self.obs_rms[key]).astype(np.float32)
            else:
                assert isinstance(self.obs_rms, RunningMeanStd)
                obs_ = self._normalize_obs(obs, self.obs_rms).astype(np.float32)
        return obs_

    def normalize_reward(self, reward: np.ndarray) -> np.ndarray:
        """
        Normalize rewards using this VecNormalize's rewards statistics.
        Calling this method does not update statistics.
        """
        if self.norm_reward:
            reward = np.clip(reward / np.sqrt(self.ret_rms.var + self.epsilon), -self.clip_reward, self.clip_reward)
        return reward.astype(np.float32)

    def unnormalize_obs(self, obs: Union[np.ndarray, Dict[str, np.ndarray]]) -> Union[np.ndarray, Dict[str, np.ndarray]]:
        # Avoid modifying by reference the original object
        obs_ = deepcopy(obs)
        if self.norm_obs:
            if isinstance(obs, dict) and isinstance(self.obs_rms, dict):
                assert self.norm_obs_keys is not None
                for key in self.norm_obs_keys:
                    obs_[key] = self._unnormalize_obs(obs[key], self.obs_rms[key])
            else:
                assert isinstance(self.obs_rms, RunningMeanStd)
                obs_ = self._unnormalize_obs(obs, self.obs_rms)
        return obs_

    def unnormalize_reward(self, reward: np.ndarray) -> np.ndarray:
        if self.norm_reward:
            return reward * np.sqrt(self.ret_rms.var + self.epsilon)
        return reward

    def get_original_obs(self) -> Union[np.ndarray, Dict[str, np.ndarray]]:
        """
        Returns an unnormalized version of the observations from the most recent
        step or reset.
        """
        return deepcopy(self.old_obs)

    def get_original_reward(self) -> np.ndarray:
        """
        Returns an unnormalized version of the rewards from the most recent step.
        """
        return self.old_reward.copy()

    def reset(self) -> Union[np.ndarray, Dict[str, np.ndarray]]:
        """
        Reset all environments
        :return: first observation of the episode
        """
        obs = self.venv.reset()
        assert isinstance(obs, (np.ndarray, dict))
        self.old_obs = obs
        self.returns = np.zeros(self.num_envs)
        if self.training and self.norm_obs:
            if isinstance(obs, dict) and isinstance(self.obs_rms, dict):
                for key in self.obs_rms.keys():
                    self.obs_rms[key].update(obs[key])
            else:
                assert isinstance(self.obs_rms, RunningMeanStd)
                self.obs_rms.update(obs)
        return self.normalize_obs(obs)

    @staticmethod
    def load(load_path: str, venv: VecEnv) -> "VecNormalize":
        """
        Loads a saved VecNormalize object.

        :param load_path: the path to load from.
        :param venv: the VecEnv to wrap.
        :return:
        """
        with open(load_path, "rb") as file_handler:
            vec_normalize = pickle.load(file_handler)
        vec_normalize.set_venv(venv)
        return vec_normalize

    def save(self, save_path: str) -> None:
        """
        Save current VecNormalize object with
        all running statistics and settings (e.g. clip_obs)

        :param save_path: The path to save to
        """
        with open(save_path, "wb") as file_handler:
            pickle.dump(self, file_handler)

class VecNormalizeRange(VecNormalize):

    def __init__(self, *args, start_idx=0, offset=None, **kwargs):
        super().__init__(*args, **kwargs)

        assert isinstance(self.observation_space, spaces.Box)
        assert len(self.observation_space.shape) == 1

        offset = self.observation_space.shape[0] if offset is None else offset

        assert offset > 0, "Offset must be positive"
        assert start_idx >= 0, "Start index must be non-negative"
        assert start_idx < self.observation_space.shape[0], "Start index must be less than the observation space dimension"

        if self.norm_obs:
            assert start_idx + offset <= self.observation_space.shape[0]

        self.obs_rms = RunningMeanStd(shape=(offset,))
        self.start_idx = start_idx
        self.offset = offset

    def reset(self) -> np.ndarray:
        obs = self.venv.reset()
        assert isinstance(obs, np.ndarray)
        self.old_obs = obs
        self.returns = np.zeros(self.num_envs)
        if self.training and self.norm_obs:
            assert isinstance(self.obs_rms, RunningMeanStd)
            obs_slice = obs[..., self.start_idx:self.start_idx + self.offset]
            self.obs_rms.update(obs_slice)
        return self.normalize_obs(obs)

    def step_wait(self) -> VecEnvStepReturn:
        obs, rewards, dones, infos = self.venv.step_wait()
        assert isinstance(obs, np.ndarray)
        self.old_obs = obs
        self.old_reward = rewards

        if self.training and self.norm_obs:
            obs_slice = obs[..., self.start_idx:self.start_idx + self.offset]
            self.obs_rms.update(obs_slice)

        obs = self.normalize_obs(obs)

        if self.training:
            self._update_reward(rewards)
        rewards = self.normalize_reward(rewards)

        # Normalize the terminal observations
        for idx, done in enumerate(dones):
            if not done:
                continue
            if "terminal_observation" in infos[idx]:
                infos[idx]["terminal_observation"] = self.normalize_obs(infos[idx]["terminal_observation"])

        self.returns[dones] = 0
        return obs, rewards, dones, infos

    def _normalize_obs(self, obs: np.ndarray, obs_rms: RunningMeanStd) -> np.ndarray:
        _obs = obs.copy()
        obs_slice = _obs[..., self.start_idx:self.start_idx + self.offset]

        #print(f"wasd623.1: obs_slice: {obs_slice}")

        obs_slice_normalized = np.clip((obs_slice - obs_rms.mean) / np.sqrt(obs_rms.var + self.epsilon), -self.clip_obs, self.clip_obs)
        _obs[..., self.start_idx:self.start_idx + self.offset] = obs_slice_normalized

        #print(f"wasd623.2: obs_slice_normalized: {obs_slice_normalized}")

        return _obs

    def _unnormalize_obs(self, obs: np.ndarray, obs_rms: RunningMeanStd) -> np.ndarray:
        _obs = obs.copy()
        obs_slice = _obs[..., self.start_idx:self.start_idx + self.offset]
        obs_slice_unnormalized = (obs_slice * np.sqrt(obs_rms.var + self.epsilon)) + obs_rms.mean
        _obs[..., self.start_idx:self.start_idx + self.offset] = obs_slice_unnormalized

        return _obs

class VecNormalizeRangeAndRewardSentenceLevelICL(VecNormalizeRange):

    def __init__(self, *args, subtract_reward_mean=False, statistics_per_sentence=True, check_rewards=True, init_return_dict={}, **kwargs):
        super().__init__(*args, **kwargs)

        #self.ret_rms = RunningMeanStd(shape=())
        self.ret_rms = {}
        self.subtract_reward_mean = subtract_reward_mean
        self.statistics_per_sentence = statistics_per_sentence
        self.check_rewards = check_rewards
        #self.init_return_dict = init_return_dict # Do not store, so the pickle file is not too large (it is not necessary to store it)
        self.assert_ret_rms_not_empty = True if len(init_return_dict) > 0 else False
        self.translation_candidate = None
        self.translation_candidate_src = None

        if len(init_return_dict) > 0:
            print(f"VecNormalizeRangeAndRewardSentenceLevelICL: initializing ret_rms with init_return_dict: {len(init_return_dict)}")

            assert np.isclose(self.gamma, 1.0)

            init_return_dict_length = []

            for c, return_list in init_return_dict.items():
                assert isinstance(c, str), f"Expected translation candidate to be a string, got {type(c)}: {c}"
                assert isinstance(return_list, list), f"Expected return_list to be a list, got {type(return_list)}: {return_list}"
                assert all(isinstance(return_value, float) for return_value in return_list), f"Expected all return values to be numbers, got {type(return_value)}: {return_value}"

                if not self.statistics_per_sentence:
                    c = "global"

                if c not in self.ret_rms:
                    self.ret_rms[c] = RunningMeanStd(shape=())

                init_return_dict_length.append(len(return_list))
                self.ret_rms[c].update(np.array(return_list))

            print(f"VecNormalizeRangeAndRewardSentenceLevelICL: initialized ret_rms with init_return_dict_length: {np.mean(init_return_dict_length)} +- {np.std(init_return_dict_length)}")

    def _check_reward(self, any_non_zeros):
        time_step = self.venv.get_attr("time_step")
        max_icl_examples = self.venv.get_attr("max_icl_examples")

        assert time_step is not None, "time_step attribute not found in the environment"
        assert max_icl_examples is not None, "max_icl_examples attribute not found in the environment"
        assert len(set(time_step)) == 1, time_step
        assert len(set(max_icl_examples)) == 1, max_icl_examples

        time_step = time_step[0]
        max_icl_examples = max_icl_examples[0]

        assert time_step >= 0, f"Expected time_step to be positive or zero, got {time_step}"
        assert max_icl_examples > 0, f"Expected max_icl_examples to be positive, got {max_icl_examples}"
        assert time_step < max_icl_examples, f"Expected time_step to be less than max_icl_examples, got time_step={time_step} and max_icl_examples={max_icl_examples}"

        if any_non_zeros:
            #assert time_step == max_icl_examples, f"Expected non-zero rewards only at the end of the episode, got time_step={time_step} and max_icl_examples={max_icl_examples}"
            assert time_step == 0, time_step # the episode is reset before this function is called, but the reward is expected at the end of the episode
        else:
            #assert time_step < max_icl_examples, f"Expected zero rewards until the end of the episode, got time_step={time_step} and max_icl_examples={max_icl_examples}"
            assert time_step > 0, time_step

    def _init_ret_rms(self) -> list[int]:
        if self.statistics_per_sentence:
            time_step = self.venv.get_attr("time_step")[0]
            #translation_candidate = self.venv.get_attr("translation_candidate")
            env_data = self.venv.get_attr("data") # we assume that the data do not change during the episode

            #print(f"wasd623.5: translation_candidate: {time_step} {self.translation_candidate} - {self.venv.get_attr('translation_candidate')}")

            if time_step == 1 and self.translation_candidate is not None:
                _translation_candidate = self.venv.get_attr("translation_candidate") # update when the environment is reset

                assert len(_translation_candidate) == self.num_envs, "The number of translation candidates must be equal to the number of environments"
                assert all(isinstance(c, int) for c in _translation_candidate), f"Expected translation_candidate to be a list of strings, got {type(_translation_candidate[0])}: {_translation_candidate[0]}"
                assert any(c1 != c2 for c1, c2 in zip(self.translation_candidate, _translation_candidate)), "Expected translation candidates to be different at the beginning of the episode"

                self.translation_candidate = _translation_candidate

            if self.translation_candidate is None:
                assert time_step == 1

                self.translation_candidate = self.venv.get_attr("translation_candidate")

            assert self.translation_candidate is not None
            assert len(self.translation_candidate) == self.num_envs, "The number of translation candidates must be equal to the number of environments"
            assert all(isinstance(c, int) for c in self.translation_candidate), f"Expected translation_candidate to be a list of strings, got {type(self.translation_candidate[0])}: {self.translation_candidate[0]}"
            assert len(env_data) == self.num_envs, "The number of env_data entries must be equal to the number of environments"

            translation_candidate_src = [e[c][0] for c, e in zip(self.translation_candidate, env_data)]

            # src_sentence, reference = self.data[self.translation_candidate]

            assert all(isinstance(c, str) for c in translation_candidate_src), f"Expected translation_candidate_src to be a list of strings, got {type(translation_candidate_src[0])}: {translation_candidate_src[0]}"

            for c in translation_candidate_src:
                if self.assert_ret_rms_not_empty:
                    assert c in self.ret_rms, f"Translation candidate not found in ret_rms: {c}"

                if c not in self.ret_rms:
                    self.ret_rms[c] = RunningMeanStd(shape=())

            self.translation_candidate_src = translation_candidate_src

            return translation_candidate_src
        else:
            if "global" not in self.ret_rms:
                self.ret_rms["global"] = RunningMeanStd(shape=())

            self.translation_candidate_src = ["global"] * self.num_envs

            return ["global"] * self.num_envs

    def _update_reward(self, reward: np.ndarray) -> None:
        assert reward.shape == (self.num_envs,), f"Expected reward to be a 1D array of shape ({self.num_envs},), got {reward.shape}"

        translation_candidate = self._init_ret_rms()
        self.returns = self.returns * self.gamma + reward
        #all_zeros = np.allclose(self.returns, np.zeros_like(self.returns))
        #none_zeros = np.all(np.logical_not(np.isclose(self.returns, np.zeros_like(self.returns))))
        any_non_zeros = np.any(np.logical_not(np.isclose(self.returns, np.zeros_like(self.returns))))

        #assert all_zeros or none_zeros, "Expected all returns to be either zero or non-zero, got: {}".format(self.returns)

        #time_step = self.venv.get_attr("time_step")[0]
        #print(f"wasd623.3: rewards: {time_step} {reward} -> {self.returns}")

        if self.check_rewards:
            self._check_reward(any_non_zeros)

        # only update the ret_rms when all returns are non-zero (episodes only return reward at the end)
        if any_non_zeros:
            if not self.statistics_per_sentence:
                assert len(set(translation_candidate)) == 1, set(translation_candidate)

            for c in set(translation_candidate):
                assert c in self.ret_rms, f"Translation candidate {c} not found in ret_rms: {list(self.ret_rms.keys())}"

                indices = np.array([i for i, candidate in enumerate(translation_candidate) if candidate == c])
                self.ret_rms[c].update(self.returns[indices])

    def normalize_reward(self, reward: np.ndarray) -> np.ndarray:
        #all_zeros = np.allclose(self.returns, np.zeros_like(self.returns))
        #none_zeros = np.all(np.logical_not(np.isclose(self.returns, np.zeros_like(self.returns))))
        any_non_zeros = np.any(np.logical_not(np.isclose(self.returns, np.zeros_like(self.returns))))

        #assert all_zeros or none_zeros, "Expected all returns to be either zero or non-zero, got: {}".format(self.returns)

        if self.check_rewards:
            self._check_reward(any_non_zeros)

        if self.norm_reward and any_non_zeros:
            translation_candidate = self.translation_candidate_src

            #time_step = self.venv.get_attr("time_step")[0]
            #print(f"wasd623.6: translation_candidate: {time_step} {self.translation_candidate} - {self.venv.get_attr('translation_candidate')}")

            rewards = np.ones_like(reward) * np.nan

            if not self.statistics_per_sentence:
                assert len(set(translation_candidate)) == 1, set(translation_candidate)

            for c in set(translation_candidate):
                assert c in self.ret_rms, f"Translation candidate {c} not found in ret_rms: {list(self.ret_rms.keys())}"

                ret_rms_mean = self.ret_rms[c].mean if self.subtract_reward_mean else 0.0
                indices = np.array([i for i, candidate in enumerate(translation_candidate) if candidate == c])

                rewards[indices] = np.clip((reward[indices] - ret_rms_mean) / np.sqrt(self.ret_rms[c].var + self.epsilon), -self.clip_reward, self.clip_reward)

                #print(f"wasd623.3: reward for candidate {c}: {reward[indices]}")
                #print(f"wasd623.4: reward_normalized for candidate {c}: {rewards[indices]}")

            assert not np.any(np.isnan(rewards)), f"NaN values found in rewards after normalization: {rewards}"
            assert rewards.shape == reward.shape, f"Expected rewards to have the same shape as input reward, got {rewards.shape} and {reward.shape}"

            reward = rewards

        return reward.astype(np.float32)

    def unnormalize_reward(self, reward: np.ndarray) -> np.ndarray:
        #all_zeros = np.allclose(self.returns, np.zeros_like(self.returns))
        #none_zeros = np.all(np.logical_not(np.isclose(self.returns, np.zeros_like(self.returns))))
        any_non_zeros = np.any(np.logical_not(np.isclose(self.returns, np.zeros_like(self.returns))))

        #assert all_zeros or none_zeros, "Expected all returns to be either zero or non-zero, got: {}".format(self.returns)

        if self.check_rewards:
            self._check_reward(any_non_zeros)

        if self.norm_reward and any_non_zeros:
            translation_candidate = self.translation_candidate_src
            rewards = np.ones_like(reward) * np.nan

            #time_step = self.venv.get_attr("time_step")[0]
            #print(f"wasd623.7: translation_candidate: {time_step} {self.translation_candidate} - {self.venv.get_attr('translation_candidate')}")

            if not self.statistics_per_sentence:
                assert len(set(translation_candidate)) == 1, set(translation_candidate)

            for c in set(translation_candidate):
                assert c in self.ret_rms, f"Translation candidate {c} not found in ret_rms: {list(self.ret_rms.keys())}"

                ret_rms_mean = self.ret_rms[c].mean if self.subtract_reward_mean else 0.0
                indices = np.array([i for i, candidate in enumerate(translation_candidate) if candidate == c])

                rewards[indices] = (reward[indices] * np.sqrt(self.ret_rms[c].var + self.epsilon)) + ret_rms_mean

            assert not np.any(np.isnan(rewards)), f"NaN values found in rewards after unnormalization: {rewards}"
            assert rewards.shape == reward.shape, f"Expected rewards to have the same shape as input reward, got {rewards.shape} and {reward.shape}"

            reward = rewards

        return reward
