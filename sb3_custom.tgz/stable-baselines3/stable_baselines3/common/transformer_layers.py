
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
import gymnasium as gym
import numpy as np

class L2Normalize(nn.Module):
    def __init__(self, eps=1e-6):
        super().__init__()
        self.eps = eps

    def forward(self, x):
        return x / (x.norm(dim=-1, keepdim=True) + self.eps)

class PositionalEncoding(nn.Module):

    def __init__(self, d_model, dropout=0.1, max_seq_len=512):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)

        pe = torch.zeros(max_seq_len, d_model)
        position = torch.arange(0, max_seq_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        #pe = pe.unsqueeze(0).transpose(0, 1)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        #x = x + self.pe[:x.size(0), :]
        x = x + self.pe[:, :x.size(1), :]
        return self.dropout(x)

class TransformerModel(nn.Module):

    def __init__(self, d_model=None, nhead=None, dim_feedforward=None, nlayers=None, projection_in=None, projection_out=None, max_seq_len=512, embedding_dropout=0.5, dropout_p=0.5, projection_out_dropout_p=0.5,
                 initial_layer_norm=False, initial_layer_norm_first=False, activation="relu", bias=True, norm_first=True, l2_norm=False, skip_n_word_embeddings_from_observation="0:0", str_id="none",
                 expected_seq_len=None, last_layer_norm=False, mean_pooling=True, last_linear_layer=False, reward_embeddings=0, remove_first_column_of_zeros=False,
                 step_embeddings=0, init_zeros_last_layer=False, use_first_n_tokens=-1, initial_layer_norm_first_additional_layer_norm_after_projection=False,
                 check_zeros=False, step_embeddings_from_observation=False, action_embeddings=0, max_actions=0, disable_step_embeddings=False, mask_tokens_p=0.0):
        kwargs = {k: v for k, v in locals().items() if k != 'self'}

        gym.logger.error("[%s] Transformer kwargs: %s", str_id, kwargs)

        assert d_model is not None
        assert nhead is not None
        assert dim_feedforward is not None
        assert nlayers is not None
        assert not l2_norm or not last_layer_norm, "warning"

        super(TransformerModel, self).__init__()

        self.initial_dim = d_model if projection_in is None else projection_in
        projection_in_dim = projection_in - (1 if remove_first_column_of_zeros else 0) if projection_in is not None else None
        initial_dim_layer_norm = self.initial_dim - (1 if remove_first_column_of_zeros else 0) if initial_layer_norm_first else d_model
        initial_dim_layer_norm2 = d_model if projection_in is not None else initial_dim_layer_norm
        self.initial_layer_norm_first = initial_layer_norm_first
        self.layer_norm = nn.LayerNorm(initial_dim_layer_norm, bias=bias) if initial_layer_norm else None
        self.layer_norm2 = nn.LayerNorm(initial_dim_layer_norm2, bias=bias) if initial_layer_norm_first_additional_layer_norm_after_projection else None
        self.pos_encoder = PositionalEncoding(d_model, embedding_dropout, max_seq_len=max_seq_len)
        encoder_layers = torch.nn.TransformerEncoderLayer(d_model, nhead, batch_first=True, dim_feedforward=dim_feedforward,
                                                          dropout=dropout_p, activation=activation, bias=bias, norm_first=norm_first)
        self.projection = nn.Linear(projection_in_dim, d_model, bias=bias) if projection_in is not None else None
        self.transformer_encoder = torch.nn.TransformerEncoder(encoder_layers, nlayers)
        self.d_model = d_model
        self.linear_initializer_range = 0.02
        self.embedding_initializer_range = 1.0
        self.expected_seq_len = expected_seq_len
        self.reward_embeddings = reward_embeddings
        self.step_embeddings = step_embeddings
        self.step_embeddings_from_observation = step_embeddings_from_observation
        self.action_embeddings = action_embeddings
        self.max_actions = max_actions
        self.remove_first_column_of_zeros = remove_first_column_of_zeros
        #self.cls_token = nn.Embedding(1, d_model) if not mean_pooling else None
        self.cls_token = nn.Embedding(1, d_model)
        self.reward_embedding_layer = nn.Embedding(reward_embeddings, self.d_model) if reward_embeddings > 0 else None
        self.step_embedding_layer = nn.Embedding(step_embeddings, self.d_model) if step_embeddings > 0 else None
        self.action_embedding_layer = nn.Embedding(action_embeddings + 1, self.d_model) if action_embeddings > 0 else None # +1 for the "no action" token
        self.init_zeros_last_layer = init_zeros_last_layer
        self.use_first_n_tokens = use_first_n_tokens if use_first_n_tokens > 0 else None
        self.check_zeros = check_zeros
        self.disable_step_embeddings = disable_step_embeddings
        self.mask_tokens_p = mask_tokens_p # Probability of masking action history and features
        self.features_mask = nn.Embedding(1, self.d_model)

        # Output
        self.pooler = nn.Linear(d_model, d_model, bias=bias) # https://github.com/huggingface/transformers/blob/5523e38b553ff6c46b04d2376870fcd842feeecc/src/transformers/models/bert/modeling_bert.py#L737
        self.pooler_activation = getattr(F, activation)
        self.projection_out_dropout = nn.Dropout(projection_out_dropout_p)
        self.projection_out = nn.Linear(d_model, projection_out, bias=bias) if projection_out is not None else None
        self.projection_activation = getattr(F, activation)
        self.projection_dropout = nn.Dropout(dropout_p)
        self.l2_norm = L2Normalize() if l2_norm else None
        self.output_dim = projection_out if projection_out is not None else d_model
        self.last_layer_norm = nn.LayerNorm(self.output_dim, bias=bias) if last_layer_norm else None
        self.str_id = str_id
        self.skip_n_word_embeddings_from_observation = skip_n_word_embeddings_from_observation.split(':')
        self.mean_pooling = mean_pooling
        self.last_linear_layer = last_linear_layer

        assert len(self.skip_n_word_embeddings_from_observation) == 2

        self.skip_n_word_embeddings_from_observation[0] = int(self.skip_n_word_embeddings_from_observation[0])
        self.skip_n_word_embeddings_from_observation[1] = int(self.skip_n_word_embeddings_from_observation[1])

        #gym.logger.error("wasd100.1: %s", self.reward_embedding_layer.weight)

        self.init_weights()

        #gym.logger.error("wasd100.2: %s", self.reward_embedding_layer.weight)

    # https://github.com/huggingface/transformers/blob/5523e38b553ff6c46b04d2376870fcd842feeecc/src/transformers/models/bert/modeling_bert.py#L836
    # https://huggingface.co/docs/transformers/model_doc/bert#transformers.BertConfig.initializer_range
    def init_weights(self):
        for module in self.modules():
            if isinstance(module, nn.Linear):
                # Slightly different from the TF version which uses truncated_normal for initialization
                # cf https://github.com/pytorch/pytorch/pull/5617
                module.weight.data.normal_(mean=0.0, std=self.linear_initializer_range)
                if module.bias is not None:
                    module.bias.data.zero_()
            elif isinstance(module, nn.Embedding):
                module.weight.data.normal_(mean=0.0, std=self.embedding_initializer_range)
                if module.padding_idx is not None:
                    module.weight.data[module.padding_idx].zero_()
            elif isinstance(module, nn.LayerNorm):
                module.weight.data.fill_(1.0)
                if module.bias is not None:
                    module.bias.data.zero_()
            #else:
            #    gym.logger.warn("Module not initialized: %s", module)

        if self.init_zeros_last_layer:
            if self.projection_out is not None:
                self.projection_out.weight.data.zero_()

                if self.projection_out.bias is not None:
                    self.projection_out.bias.data.zero_()
            elif self.last_linear_layer:
                self.pooler.weight.data.zero_()

                if self.pooler.bias is not None:
                    self.pooler.bias.data.zero_()

    def get_reward_embedding(self, idx, device="cpu"):
        assert False, "EXTREMELY slow, do not use"
        assert self.reward_embedding_layer is not None, "No reward embedding layer defined"
        assert isinstance(idx, int), idx
        assert idx >= 0, idx
        assert idx < self.reward_embeddings, f"Index {idx} out of range for total embeddings {self.reward_embeddings}"

        result = self.reward_embedding_layer(torch.tensor([idx], device=device))

        assert result.shape == (1, self.d_model), f"Unexpected shape for reward embedding: {result.shape} (idx: {idx})"

        result = result.squeeze(0)

        return result

    def get_step_embedding(self, idx, device="cpu"):
        assert False, "EXTREMELY slow, do not use"
        assert self.step_embedding_layer is not None, "No step embedding layer defined"
        assert isinstance(idx, int), idx
        assert idx >= 0, idx
        assert idx < self.step_embeddings, f"Index {idx} out of range for total embeddings {self.step_embeddings}"

        result = self.step_embedding_layer(torch.tensor([idx], device=device))

        assert result.shape == (1, self.d_model), f"Unexpected shape for step embedding: {result.shape} (idx: {idx})"

        result = result.squeeze(0)

        return result

    def reshape_embeddings_2to3(self, src):
        assert len(src.shape) == 2, src.shape
        assert src.shape[-1] % self.initial_dim == 0, f"Observation shape[-1] was expected to be mod {self.initial_dim}, but got {src.shape[-1]}: {src[0]}"

        projection_in_n_times = src.shape[-1] // self.initial_dim
        new_shape = (src.shape[0], projection_in_n_times, self.initial_dim)

        #gym.logger.error("wasd4: embeddings reshape (id: %s): %s -> %s", self.str_id, src.shape, new_shape)

        #gym.logger.error("wasd11 %s %s %s %s", src.shape, new_shape, src, src.reshape(new_shape))

        src = src.reshape(new_shape)

        assert len(src.shape) == 3, src.shape

        #gym.logger.error("wasd30 %s: %s", src.shape, src[0,0,:])

        #if src.shape[1] > 1540:
        #    gym.logger.error("wasd31 critic: %s %s %s %s", src[0,1022:1024,:], src[0,1024:1026,:], src[0,2046:2048,:], src[0,2048:2050,:])
        #else:
        #    gym.logger.error("wasd31  actor: %s %s", src[0,1022:1024,:], src[0,1024:1026,:])

        return src

    def forward(self, src, mask=None, reward_embedding_idxs=None, step_embedding_idxs=None):
        #gym.logger.error("wasd6321: self.training: %s", self.training)
        assert mask is None, mask

        if self.reward_embeddings > 0:
            assert reward_embedding_idxs is not None

        assert len(src.shape) == 2, src.shape # (batch_size, seq_len * initial_dim)

        if self.step_embeddings_from_observation:
            step_embedding_idxs_copy = step_embedding_idxs
            _step_embedding_idxs, src = src[:, :self.step_embeddings], src[:, self.step_embeddings:]
            step_embedding_idxs = []
            _step_embedding_idxs = (_step_embedding_idxs + 0.5).long().detach().cpu()

            for step_embedding in _step_embedding_idxs:
                assert torch.count_nonzero(step_embedding).item() == 1, f"Expected exactly one non-zero value in the step embedding indices, but got {step_embedding} (shape: {step_embedding.shape})"
                assert torch.sum(step_embedding) == 1

                position = torch.nonzero(step_embedding).item()

                assert position >= 0 and position < self.step_embeddings, f"Step embedding index {position} out of range for total step embeddings {self.step_embeddings}"

                step_embedding_idxs.append(position)

            if step_embedding_idxs_copy is not None:
                assert step_embedding_idxs == step_embedding_idxs_copy, f"Step embedding indices from observation {step_embedding_idxs} do not match the provided step embedding indices {step_embedding_idxs_copy}"

        if self.action_embeddings > 0:
            # we expect the history of actions at the end of the sequence, so we take the last action embedding index from the observation
            src, action_embedding_one_hot_float = src[:, :-self.action_embeddings], src[:, -self.action_embeddings:]

            assert len(action_embedding_one_hot_float.shape) == 2, action_embedding_one_hot_float.shape
            assert self.max_actions > 0
            assert self.action_embeddings >= self.max_actions, f"Total action embeddings (including the 'no action' token) must be greater than max_actions: {self.action_embeddings} vs {self.max_actions}"

            action_embedding_one_hot = (action_embedding_one_hot_float + 0.5).long().detach()

            if step_embedding_idxs is not None:
                # check that the number of selected examples is equal to the time step
                assert len(step_embedding_idxs) == action_embedding_one_hot.shape[0]

                for step_embedding_idx, action_embedding in zip(step_embedding_idxs, action_embedding_one_hot):
                    assert torch.sum(action_embedding).item() == step_embedding_idx, f"Expected the number of selected examples (sum of action embedding) to be equal to the time step (step embedding index), but got {torch.sum(action_embedding).item()} vs {step_embedding_idx}"

        if self.step_embeddings > 0:
            assert step_embedding_idxs is not None

            #gym.logger.error("wasd56.2: time_steps: %s", step_embedding_idxs)

        if reward_embedding_idxs is not None and self.reward_embeddings > 0:
            assert isinstance(reward_embedding_idxs, list), reward_embedding_idxs
            assert all(isinstance(idx, int) for idx in reward_embedding_idxs), reward_embedding_idxs
            assert all(idx >= 0 for idx in reward_embedding_idxs), reward_embedding_idxs
            assert all(idx < self.reward_embeddings for idx in reward_embedding_idxs), reward_embedding_idxs

        if step_embedding_idxs is not None and self.step_embeddings > 0:
            assert isinstance(step_embedding_idxs, list), step_embedding_idxs
            assert all(isinstance(idx, int) for idx in step_embedding_idxs), step_embedding_idxs
            assert all(idx >= 0 for idx in step_embedding_idxs), step_embedding_idxs
            assert all(idx < self.step_embeddings for idx in step_embedding_idxs), step_embedding_idxs

        # Fix shape
        src = self.reshape_embeddings_2to3(src.clone())

        assert src.shape[2] == self.initial_dim

        #gym.logger.error("wasd99.1: %s: %s", src.shape, src)

        if self.skip_n_word_embeddings_from_observation[0] != self.skip_n_word_embeddings_from_observation[1]:
            start, end = self.skip_n_word_embeddings_from_observation

            if start < 0:
                start += src.shape[1] + 1
            if end < 0:
                end += src.shape[1] + 1

            assert start <= end, self.skip_n_word_embeddings_from_observation

            if end <= src.shape[1] and (end - start) < src.shape[1]: # we are in the limits and the total of removed elements is not greater than seq_len
                #tmp_src = torch.zeros_like(src)
                #tmp_src[:, :start] = src[:, :start]
                #tmp_src[:, start:src.shape[1] - end + start] = src[:, end:]
                #src = tmp_src
                left_part = src[:, :start]
                right_part = src[:, end:]

                #gym.logger.error("wasd8: %s %s", left_part.shape, right_part.shape)

                if self.check_zeros:
                    #assert torch.all(src[:,end,0] == 0).item(), f"{end}: {src[:,end]}" # Custom code
                    #assert torch.all(src[:,end - 1,0] != 0).item(), f"{end - 1}: {src[:,end - 1]}" # Custom code
                    #assert torch.all(src[:,end - 2,0] == 0).item(), f"{end - 2}: {src[:,end - 2]}" # Custom code (-2 to ignore the custom position tokens)
                    #assert torch.all(src[:,end - 2 - 1,0] != 0).item(), f"{end - 2 - 1}: {src[:,end - 2 - 1]}" # Custom code (-2 to ignore the custom position tokens)
                    assert torch.all(src[:,end - 2:,0] == 0).item(), f"{end - 2}: {src[:,end - 2]}" # Custom code (-2 to ignore the custom position tokens)
                    assert torch.all(src[:,:end - 2 - 1,0] != 0).item(), f"{end - 2 - 1}: {src[:,end - 2 - 1]}" # Custom code (-2 to ignore the custom position tokens)

                #padding = torch.zeros_like(src[:, :end - start])
                #src = torch.cat((left_part, right_part, padding), dim=1)
                src = torch.cat((left_part, right_part), dim=1)
            else:
                gym.logger.warn("Could not remove the elements (%s, %s): %s", start, end, src.shape)

        #for i in range(1, src.shape[2]):
        #    assert torch.any(src[:, :, i] != 0).item(), f"Expected column {i} to not be all zeros, but got {src[:, :, i]} (shape: {src.shape}) (id: {self.str_id})"

        # remove first column of zeros
        if self.remove_first_column_of_zeros:
            assert torch.all(src[:, :, 0] == 0).item(), f"Expected the first column to be all zeros, but got {src[:, :, 0]} (shape: {src.shape}) (id: {self.str_id})"

            src = src[:, :, 1:]

        if self.expected_seq_len is not None:
            assert src.shape[1] == self.expected_seq_len, f"Expected sequence length {self.expected_seq_len}, but got {src.shape[1]} (shape: {src.shape}) (id: {self.str_id})"

        if self.use_first_n_tokens is not None:
            src[:, self.use_first_n_tokens:, :] = 0.0

        #gym.logger.error("wasd99.2: %s: %s", src.shape, src)

        # Create mask (zero word embeddings are considered padding)
        non_zero_values = (src != 0)
        mask = non_zero_values.any(dim=-1) # bool
        mask = ~mask # invert: True means padding

        assert len(mask.shape) == 2, mask.shape
        assert mask.shape == src.shape[:2], f"{mask.shape} vs {src.shape[:2]}"
        assert (src * (~mask).unsqueeze(-1) == src).all().detach().cpu().item()

        #gym.logger.error("wasd12 %s %s %s", mask.shape, mask, np.isnan(mask.detach().cpu().numpy()).any(axis=len(mask.shape) - 1).sum())

        # Statistics
        is_zero_vector = (src.detach().cpu() == 0).all(dim=2)
        count_per_batch = is_zero_vector.sum(dim=1)

        #gym.logger.error("wasd5: embeddings zero: %s", count_per_batch)
        #gym.logger.error("wasd6: mask: %s", torch.sum(mask, dim=1))

        if src.shape[0] == 1: # inference
            gym.logger.error("wasd7.2 (mask: %s): %s: %s: %s: %s:\n%s", torch.sum(mask, dim=1), src.shape, torch.sum(src, dim=(1, 2)), reward_embedding_idxs, step_embedding_idxs, src[:,:5])

        # Transformer
        if self.initial_layer_norm_first:
            src = self.layer_norm(src) if self.layer_norm is not None else src

        src = self.projection(src) if self.projection is not None else src
        src = self.projection_activation(src) if self.projection is not None else src

        # Mask the features of the masked tokens with probability self.mask_tokens_p (setting them to self.features_mask)
        if self.mask_tokens_p > 0.0 and self.training: # Only apply masking during training
            random_mask = (torch.rand_like(mask.float()) < self.mask_tokens_p) & (~mask) # Only consider non-padding tokens for masking
            percentage_masked = (random_mask.float().sum() / (~mask).float().sum()).item() * 100

            #gym.logger.error("wasd6321: percentage_masked features: %s", percentage_masked)

            if random_mask.any():
                src[random_mask] = self.features_mask(torch.zeros(1, dtype=torch.long, device=src.device))

        if self.initial_layer_norm_first:
            src = self.layer_norm2(src) if self.layer_norm2 is not None else src
        else:
            src = self.layer_norm(src) if self.layer_norm is not None else src

        src = self.projection_dropout(src) if self.projection is not None else src

        assert len(src.shape) == 3, src.shape
        assert src.shape[2] == self.d_model, f"{src.shape} vs {self.d_model} (id: {self.str_id})"

        #gym.logger.error("wasd99.3: %s: %s", src.shape, src)

        if self.action_embeddings > 0:
            # Prepend action tokens
            # action_embedding_one_hot_float and action_embedding_one_hot already defined

            # We expect each action to have a difference of 1e-4 * time_step, so we can sort them and get the indices of the actions in the order they were taken
            sorted_idxs = torch.argsort(action_embedding_one_hot_float, dim=1, descending=True)

            assert len(sorted_idxs.shape) == 2, sorted_idxs.shape
            assert sorted_idxs.shape[1] == self.action_embeddings, f"{sorted_idxs.shape} vs {self.action_embeddings}"

            sorted_idxs = sorted_idxs[:, :self.max_actions] # keep only the top max_actions

            #print(f"asd1: {action_embedding_one_hot_float} {sorted_idxs}")

            assert torch.allclose(torch.sum(action_embedding_one_hot, dim=1), torch.sum(torch.gather(action_embedding_one_hot, dim=1, index=sorted_idxs), dim=1))

            # Check that no value in action_embedding_one_hot_float[sorted_idxs] is equal among them (avoiding comparing the same idx with itself):
            #idxs_arange = torch.arange(action_embedding_one_hot_float.shape[0])

            #for i in range(sorted_idxs.shape[1]):
            #    for j in range(i + 1, sorted_idxs.shape[1]):
            #        assert not torch.isclose(action_embedding_one_hot_float[idxs_arange, sorted_idxs[:, i]], action_embedding_one_hot_float[idxs_arange, sorted_idxs[:, j]]).any(), f"Expected all values in action_embedding_one_hot_float at the sorted indices to be different, but got {action_embedding_one_hot_float[idxs_arange, sorted_idxs[:, i]]} vs {action_embedding_one_hot_float[idxs_arange, sorted_idxs[:, j]]}"

            # Create embeddings
            assert sorted_idxs.shape == (src.shape[0], self.max_actions), f"{sorted_idxs.shape} vs {(src.shape[0], self.max_actions)}"

            sorted_idxs = sorted_idxs + 1 # shift by 1 to account for the "no action" token
            #sorted_idxs = sorted_idxs * (action_embedding_one_hot[sorted_idxs - 1] != 0).long() # Set idx 0 if the action embedding of that actions was not taken (where action_embedding_one_hot is 0)
            sorted_idxs = sorted_idxs * (torch.gather(action_embedding_one_hot, dim=1, index=(sorted_idxs - 1)) != 0).long() # Set idx 0 if the action embedding of that actions was not taken (where action_embedding_one_hot is 0)

            if self.mask_tokens_p > 0.0 and self.training: # Only apply masking during training
                random_mask = (torch.rand_like(sorted_idxs.float()) < self.mask_tokens_p) & (sorted_idxs != 0) # Only consider non-zero indices for masking
                percentage_masked = (random_mask.float().sum() / (sorted_idxs != 0).float().sum()).item() * 100
                #gym.logger.error("wasd6321: percentage_masked actions: %s", percentage_masked)
                mask_tokens = (~random_mask).long() # Randomly select some tokens to mask
                sorted_idxs = sorted_idxs * mask_tokens # Set idx to 0 for the masked tokens

            action_embeddings = self.action_embedding_layer(sorted_idxs.to(src.device))

            #print(f"asd2: {action_embedding_one_hot_float} {sorted_idxs}")

            assert action_embeddings.shape == (src.shape[0], self.max_actions, self.d_model), f"{action_embeddings.shape} vs {(src.shape[0], self.max_actions, self.d_model)}"

            src = torch.cat((action_embeddings, src), dim=1) # prepend the embeddings
            embeddings_mask = torch.zeros((src.shape[0], self.max_actions), dtype=torch.bool, device=mask.device)
            embeddings_mask[:, :self.max_actions] = (sorted_idxs == 0) # Mask the positions where the action embedding was not taken (sorted_idxs set to 0 means that action_embedding_one_hot was 0 for that position)
            mask = torch.cat((embeddings_mask, mask), dim=1) # concatenate mask to match src length

        if step_embedding_idxs is not None and self.step_embeddings > 0:
            # Prepend time step tokens
            #step_embeddings = torch.stack([self.get_step_embedding(idx, device=src.device) for idx in step_embedding_idxs], dim=0) # EXTREMELY slow
            step_embeddings = self.step_embedding_layer(torch.as_tensor(step_embedding_idxs).to(src.device))

            assert step_embeddings.shape == (src.shape[0], self.d_model), f"{step_embeddings.shape} vs {src.shape}"

            step_embeddings = step_embeddings.unsqueeze(1) # add sequence dimension

            assert step_embeddings.shape[0] == src.shape[0], f"{step_embeddings.shape} vs {src.shape}"
            assert step_embeddings.shape[1] == 1, f"{step_embeddings.shape} vs 1"
            assert step_embeddings.shape[2] == src.shape[2], f"{step_embeddings.shape} vs {src.shape}"

            if not self.disable_step_embeddings:
                src = torch.cat((step_embeddings, src), dim=1) # prepend the step embeddings
                step_embeddings_mask = torch.zeros((src.shape[0], 1), dtype=torch.bool, device=mask.device)
                mask = torch.cat((step_embeddings_mask, mask), dim=1) # concatenate mask to match src length

            #for batch_idx, idx in enumerate(step_embedding_idxs):
            #    assert torch.allclose(src[batch_idx, 0, :], self.get_step_embedding(idx, device=src.device))

        if reward_embedding_idxs is not None and self.reward_embeddings > 0:
            # Prepend reward tokens
            #reward_embeddings = torch.stack([self.get_reward_embedding(idx, device=src.device) for idx in reward_embedding_idxs], dim=0) EXTREMELY slow
            reward_embeddings = self.reward_embedding_layer(torch.as_tensor(reward_embedding_idxs).to(src.device))

            assert reward_embeddings.shape == (src.shape[0], self.d_model), f"{reward_embeddings.shape} vs {src.shape}"

            reward_embeddings = reward_embeddings.unsqueeze(1) # add sequence dimension

            assert reward_embeddings.shape[0] == src.shape[0], f"{reward_embeddings.shape} vs {src.shape}"
            assert reward_embeddings.shape[1] == 1, f"{reward_embeddings.shape} vs 1"
            assert reward_embeddings.shape[2] == src.shape[2], f"{reward_embeddings.shape} vs {src.shape}"

            src = torch.cat((reward_embeddings, src), dim=1) # prepend the reward embeddings
            reward_embeddings_mask = torch.zeros((src.shape[0], 1), dtype=torch.bool, device=mask.device)
            mask = torch.cat((reward_embeddings_mask, mask), dim=1) # concatenate mask to match src length

            #for batch_idx, idx in enumerate(reward_embedding_idxs):
            #    assert torch.allclose(src[batch_idx, 0, :], self.get_reward_embedding(idx, device=src.device))

        #gym.logger.error("wasd99.4: %s: %s", src.shape, src)

        #if not self.mean_pooling:
        if True:
            # Prepend CLS token
            assert self.cls_token is not None

            cls_tokens = self.cls_token(torch.tensor([0], device=src.device).expand(src.shape[0], -1))

            assert cls_tokens.shape[0] == src.shape[0], f"{cls_tokens.shape} vs {src.shape}"
            assert cls_tokens.shape[1] == 1, f"{cls_tokens.shape} vs 1"
            assert cls_tokens.shape[2] == src.shape[2], f"{cls_tokens.shape} vs {src.shape}"

            src = torch.cat((cls_tokens, src), dim=1) # prepend the cls token
            cls_mask = torch.zeros((src.shape[0], 1), dtype=torch.bool, device=mask.device)
            mask = torch.cat((cls_mask, mask), dim=1) # concatenate mask to match src length

            assert torch.allclose(src[:, 0, :], cls_tokens)

#        if reward_embedding_idxs is not None and self.reward_embeddings > 0:
#            position_idx = 1 if not self.mean_pooling else 0
#
#            #for batch_idx, idx in enumerate(reward_embedding_idxs):
#            #    assert torch.allclose(src[batch_idx, position_idx, :], self.get_reward_embedding(idx, device=src.device)) EXTREMELY slow
#
#        if step_embedding_idxs is not None and self.step_embeddings > 0:
#            position_idx = 1 if not self.mean_pooling else 0
#            position_idx += 1 if reward_embedding_idxs is not None and self.reward_embeddings > 0 else 0
#
#            #for batch_idx, idx in enumerate(step_embedding_idxs):
#            #    assert torch.allclose(src[batch_idx, position_idx, :], self.get_step_embedding(idx, device=src.device)) EXTREMELY slow

        #if self.mean_pooling:
            #gym.logger.error("Custom features std: %s", src[:, 2:, :].std().item())
            #gym.logger.error("Reward token std: %s", src[:, 0, :].std().item())
            #gym.logger.error("Step token std: %s", src[:, 1, :].std().item())
        #else:
            #gym.logger.error("Custom features std: %s", src[:, 3:, :].std().item())
            #gym.logger.error("CLS token std: %s", src[:, 0, :].std().item())
            #gym.logger.error("Reward token std: %s", src[:, 1, :].std().item())
            #gym.logger.error("Step token std: %s", src[:, 2, :].std().item())

        #gym.logger.error("wasd99.5: %s: %s", src.shape, src)

        if src.shape[0] == 1: # inference
            gym.logger.error("wasd7.3 (mask: %s): %s: %s:\n%s", torch.sum(mask, dim=1), src.shape, torch.sum(src, dim=(1, 2)), src[:,:5])

        # Run
        src = self.pos_encoder(src)
        output = self.transformer_encoder(src, src_key_padding_mask=mask)

        assert len(output.shape) == 3, output.shape
        assert output.shape == src.shape, f"{output.shape} vs {src.shape}"

        # https://github.com/huggingface/transformers/blob/5523e38b553ff6c46b04d2376870fcd842feeecc/src/transformers/models/bert/modeling_bert.py#L1680
        # Same dropout layer twice: https://github.com/huggingface/transformers/blob/78bb85146c59258a0710c8d08311d98d52303c38/src/transformers/models/roberta/modeling_roberta.py#L1201
        if self.mean_pooling:
            #output = output.mean(dim=1) # Mean pooling # This is wrong! Padding is considered in the average

            valid_token_mask = (~mask).float() # 1.0 for valid tokens, 0.0 for padding
            input_mask_expanded = valid_token_mask.unsqueeze(-1).expand(output.size()) # (batch_size, seq_len, d_model)
            sum_embeddings = torch.sum(output * input_mask_expanded, dim=1) # (batch_size, d_model) sum of valid token embeddings
            sum_mask = torch.clamp(input_mask_expanded.sum(dim=1), min=1e-9) # (batch_size, d_model) number of valid tokens (clamped to avoid division by zero, although it should not happen)
            output = sum_embeddings / sum_mask # mean pooling
        else:
            output = output[:,0,:] # Only the first token (CLS)

        if self.last_linear_layer:
            output = self.projection_out_dropout(output)
            output = self.pooler(output)
            #output = self.pooler_activation(output)
            if self.projection_out is not None:
                output = self.pooler_activation(output)

        if self.projection_out is not None:
            output = self.projection_out_dropout(output)
            output = self.projection_out(output) # logits

        if self.l2_norm is not None:
            output = self.l2_norm(output)

        if self.last_layer_norm is not None:
            output = self.last_layer_norm(output)

        assert len(output.shape) == 2, output.shape
        assert output.shape[0] == src.shape[0], f"{output.shape} vs {src.shape}"
        assert output.shape[1] == self.output_dim, f"{output.shape} vs {self.output_dim}"

        if output.shape[0] == 1: # inference
            gym.logger.error("wasd9: %s: %s:\n%s", output.shape, torch.sum(output, dim=1), output)

        return output
