from typing import Dict, List, Tuple, Type, Union, Optional, Any
import datetime

import gymnasium as gym
import torch as th
from gymnasium import spaces
from torch import nn

from stable_baselines3.common.preprocessing import get_flattened_obs_dim, is_image_space
from stable_baselines3.common.type_aliases import TensorDict
from stable_baselines3.common.utils import get_device
from stable_baselines3.common.transformer_layers import TransformerModel, L2Normalize

class BaseFeaturesExtractor(nn.Module):
    """
    Base class that represents a features extractor.

    :param observation_space:
    :param features_dim: Number of features extracted.
    """

    def __init__(self, observation_space: gym.Space, features_dim: int = 0) -> None:
        super().__init__()
        assert features_dim > 0
        self._observation_space = observation_space
        self._features_dim = features_dim

    @property
    def features_dim(self) -> int:
        return self._features_dim


class FlattenExtractor(BaseFeaturesExtractor):
    """
    Feature extract that flatten the input.
    Used as a placeholder when feature extraction is not needed.

    :param observation_space:
    """

    def __init__(self, observation_space: gym.Space) -> None:
        super().__init__(observation_space, get_flattened_obs_dim(observation_space))
        self.flatten = nn.Flatten()

    def forward(self, observations: th.Tensor) -> th.Tensor:
        return self.flatten(observations)


class NoFlattenExtractor(FlattenExtractor):

    def __init__(self, observation_space: gym.Space) -> None:
        super().__init__(observation_space)
        self.flatten = None

    def forward(self, observations: th.Tensor) -> th.Tensor:
        return observations


class NatureCNN(BaseFeaturesExtractor):
    """
    CNN from DQN Nature paper:
        Mnih, Volodymyr, et al.
        "Human-level control through deep reinforcement learning."
        Nature 518.7540 (2015): 529-533.

    :param observation_space:
    :param features_dim: Number of features extracted.
        This corresponds to the number of unit for the last layer.
    :param normalized_image: Whether to assume that the image is already normalized
        or not (this disables dtype and bounds checks): when True, it only checks that
        the space is a Box and has 3 dimensions.
        Otherwise, it checks that it has expected dtype (uint8) and bounds (values in [0, 255]).
    """

    def __init__(
        self,
        observation_space: gym.Space,
        features_dim: int = 512,
        normalized_image: bool = False,
    ) -> None:
        assert isinstance(observation_space, spaces.Box), (
            "NatureCNN must be used with a gym.spaces.Box ",
            f"observation space, not {observation_space}",
        )
        super().__init__(observation_space, features_dim)
        # We assume CxHxW images (channels first)
        # Re-ordering will be done by pre-preprocessing or wrapper
        assert is_image_space(observation_space, check_channels=False, normalized_image=normalized_image), (
            "You should use NatureCNN "
            f"only with images not with {observation_space}\n"
            "(you are probably using `CnnPolicy` instead of `MlpPolicy` or `MultiInputPolicy`)\n"
            "If you are using a custom environment,\n"
            "please check it using our env checker:\n"
            "https://stable-baselines3.readthedocs.io/en/master/common/env_checker.html.\n"
            "If you are using `VecNormalize` or already normalized channel-first images "
            "you should pass `normalize_images=False`: \n"
            "https://stable-baselines3.readthedocs.io/en/master/guide/custom_env.html"
        )
        n_input_channels = observation_space.shape[0]
        self.cnn = nn.Sequential(
            nn.Conv2d(n_input_channels, 32, kernel_size=8, stride=4, padding=0),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2, padding=0),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=0),
            nn.ReLU(),
            nn.Flatten(),
        )

        # Compute shape by doing one forward pass
        with th.no_grad():
            n_flatten = self.cnn(th.as_tensor(observation_space.sample()[None]).float()).shape[1]

        self.linear = nn.Sequential(nn.Linear(n_flatten, features_dim), nn.ReLU())

    def forward(self, observations: th.Tensor) -> th.Tensor:
        return self.linear(self.cnn(observations))

class TransformerExtractor(BaseFeaturesExtractor):
    """
    Feature extractor that uses a Transformer model.

    :param observation_space:
    :param transformer_kwargs: Arguments to create the TransformerModel.
    """

    def __init__(
        self,
        observation_space: gym.Space,
        **transformer_kwargs,
    ) -> None:
        assert isinstance(observation_space, spaces.Box), (
            "TransformerExtractor must be used with a gym.spaces.Box ",
            f"observation space, not {observation_space}",
        )
        assert "d_model" in transformer_kwargs, transformer_kwargs

        features_dim = transformer_kwargs.get("projection_out", None)

        if features_dim is None:
            features_dim = transformer_kwargs["d_model"]

        assert isinstance(features_dim, int), f"features_dim must be an integer, got: {features_dim}"
        assert features_dim > 0, f"features_dim must be positive, got: {features_dim}"

        super().__init__(observation_space, features_dim=features_dim)

        self.transformer = TransformerModel(**transformer_kwargs)

    def forward(self, observations: th.Tensor, step_embedding_idxs: Optional[List[int]] = None) -> th.Tensor:
        return self.transformer(observations, step_embedding_idxs=step_embedding_idxs)

class NFeaturesExtractor(BaseFeaturesExtractor):
    """
    Return the first N components of the flattened state

    :param observation_space:
    """

    def __init__(self, observation_space: gym.Space, n: int = 0, skip_n: int = 0, state_dim_per_token: Optional[int] = None, check_zeros: bool = False, fdim: int = None) -> None:
        assert n > 0, n
        assert skip_n >= 0, skip_n

        super().__init__(observation_space, fdim if fdim is not None else n)
        self.flatten = nn.Flatten()
        self.n = n
        self.skip_n = skip_n
        self.state_dim_per_token = state_dim_per_token
        self.check_zeros = check_zeros

        if self.check_zeros:
            assert self.state_dim_per_token is not None
            assert self.n % self.state_dim_per_token == 0, f"n must be a multiple of state_dim_per_token: {self.n} vs {self.state_dim_per_token}"
            assert self.skip_n % self.state_dim_per_token == 0, f"skip_n must be a multiple of state_dim_per_token: {self.skip_n} vs {self.state_dim_per_token}"

    def forward(self, observations: th.Tensor, final_shape_check: bool = True) -> th.Tensor:
        assert isinstance(observations, th.Tensor), type(observations)
        assert observations.shape[-1] >= self.n, f"{observations.shape[-1]} < {self.n}"
        assert len(observations.shape) in (1, 2), observations.shape

        if self.check_zeros:
            assert observations.shape[-1] % self.state_dim_per_token == 0, f"Observation shape[-1] was expected to be mod {self.state_dim_per_token}, but got {observations.shape[-1]}"

            tmp_projection_in_n_times = observations.shape[-1] // self.state_dim_per_token

            if len(observations.shape) == 1:
                tmp_bsz = 1
            elif len(observations.shape) == 2:
                tmp_bsz = observations.shape[0]
            else:
                raise Exception()

            tmp_observations = observations.detach().cpu().reshape(tmp_bsz, -1, self.state_dim_per_token)

            assert tmp_observations.shape[1] == tmp_projection_in_n_times, f"{tmp_observations.shape}: {tmp_observations.shape[1]} vs {tmp_projection_in_n_times}"
            #assert th.all(tmp_observations[:,self.skip_n // self.state_dim_per_token:,0] == 0).item()
            #assert th.all(tmp_observations[:,:self.skip_n // self.state_dim_per_token - 1,0] != 0).item()
            assert th.all(tmp_observations[:,self.skip_n // self.state_dim_per_token - 2:,0] == 0).item() # Custom code (-2 to ignore the custom position tokens)
            assert th.all(tmp_observations[:,:self.skip_n // self.state_dim_per_token - 1 - 2,0] != 0).item() # Custom code (-2 to ignore the custom position tokens)

        result = self.flatten(observations)[...,self.skip_n:self.skip_n + self.n]

        assert len(result.shape) == len(observations.shape)

        #gym.logger.error("asd99.1: %s: %s", observations.shape, observations if len(result.shape) == 1 else observations[0])
        #gym.logger.error("asd99.2: %s: %s", result.shape, result if len(result.shape) == 1 else result[0])

        if final_shape_check:
            assert result.shape[-1] == self.n, f"{result.shape[-1]} != {self.n}"

        return result

class NFeaturesExtractorWithTimeStepEmbeddings(NFeaturesExtractor):
    def __init__(self, observation_space: gym.Space, n: int = 0, skip_n: int = 0, state_dim_per_token: Optional[int] = None, check_zeros: bool = False, step_embeddings: int = 0, step_embeddings_dim: int = 0, linear_bottleneck: int = 0, activation_fn: nn.Module = nn.ReLU,
                 use_transformer: bool = False, transformer_kwargs: Dict[str, Any] = None, custom_features_dim: int = None) -> None:
        super().__init__(observation_space, n=n, skip_n=skip_n, state_dim_per_token=state_dim_per_token, check_zeros=check_zeros, fdim=custom_features_dim if custom_features_dim is not None else linear_bottleneck if linear_bottleneck > 0 else n)

        self.step_embedding_layer = None
        self.step_embeddings = step_embeddings
        self.step_embeddings_dim = step_embeddings_dim

        if step_embeddings > 0:
            assert step_embeddings_dim > 0, step_embeddings

            self.step_embedding_layer = nn.Embedding(step_embeddings, step_embeddings_dim)

        self.linear_layer = nn.Linear(self.n, linear_bottleneck) if linear_bottleneck > 0 else None
        self.activation_layer = activation_fn() if linear_bottleneck > 0 else None
        self.transformer = TransformerModel(**transformer_kwargs) if use_transformer else None

        if use_transformer:
            assert self.step_embeddings <= 0, "Use the transformer kwargs for this feature"
            assert self.step_embeddings_dim <= 0, "Use the transformer kwargs for this feature"
            assert linear_bottleneck <= 0, "Use the transformer kwargs (projection_out) for this feature"

    def get_step_embedding(self, idx, device="cpu"):
        assert self.step_embedding_layer is not None, "No step embedding layer defined"
        assert isinstance(idx, int), idx
        assert idx >= 0, idx
        assert idx < self.step_embeddings, f"Index {idx} out of range for total embeddings {self.step_embeddings}"

        result = self.step_embedding_layer(th.tensor([idx], device=device))

        assert result.shape == (1, self.step_embeddings_dim), f"Unexpected shape for step embedding: {result.shape} (idx: {idx})"

        result = result.squeeze(0)

        return result

    def forward(self, observations: th.Tensor, final_shape_check: bool = True, step_embedding_idxs: Optional[List[int]] = None) -> th.Tensor:
        #gym.logger.info("wasd 562.4: datetime init: %s", datetime.datetime.now())
        result = super().forward(observations, final_shape_check=False)

        assert len(result.shape) in (1, 2), result.shape
        #gym.logger.info("wasd 562.4: datetime 2: %s", datetime.datetime.now())
        if step_embedding_idxs is not None and self.step_embeddings > 0:
            assert isinstance(step_embedding_idxs, list), step_embedding_idxs
            assert all(isinstance(idx, int) for idx in step_embedding_idxs), step_embedding_idxs
            assert all(idx >= 0 for idx in step_embedding_idxs), step_embedding_idxs
            assert all(idx < self.step_embeddings for idx in step_embedding_idxs), step_embedding_idxs

        #gym.logger.info("wasd 562.4: datetime 3: %s", datetime.datetime.now())
        if step_embedding_idxs is not None and self.step_embeddings > 0:
            #step_embeddings = self.step_embedding_layer(th.as_tensor(step_embedding_idxs, device=result.device))
            #result = th.cat((step_embeddings, result), dim=-1)

            #step_embeddings = th.stack([self.get_step_embedding(idx, device=result.device) for idx in step_embedding_idxs], dim=0) # EXTREMELY slow
            step_embeddings = self.step_embedding_layer(th.as_tensor(step_embedding_idxs).to(result.device))
            expected_shape = (result.shape[0] if len(result.shape) == 2 else 1, self.step_embeddings_dim)

            assert step_embeddings.shape == expected_shape, f"{step_embeddings.shape} vs {expected_shape} ({result.shape})"
            assert step_embeddings.shape[0] == result.shape[0] if len(result.shape) == 2 else 1, f"{step_embeddings.shape} vs {result.shape[0] if len(result.shape) == 2 else 1}"
            assert step_embeddings.shape[-1] == self.step_embeddings_dim, f"{step_embeddings.shape} vs {self.step_embeddings_dim}"

            #gym.logger.info("wasd 562.4: datetime 3.1: %s", datetime.datetime.now())

            if len(result.shape) == 1:
                assert step_embeddings.shape[0] == 1

                step_embeddings = step_embeddings.squeeze(0)

            result = th.cat((step_embeddings, result), dim=-1) # prepend the step embeddings

            #gym.logger.error("asd231.1: %s: %s %s", observations.shape, observations[...,:20], observations[...,-20:])
            #gym.logger.error("asd231.2: %s: %s %s", result.shape, result[...,:20], result[...,-20:])

        if self.transformer is not None:
            result = self.transformer(result, step_embedding_idxs=step_embedding_idxs)

        if final_shape_check:
            output_check = self.n if self.transformer is None else self.transformer.output_dim

            assert result.shape[-1] == output_check, f"{result.shape[-1]} != {output_check}"

        #gym.logger.info("wasd 562.4: datetime end: %s", datetime.datetime.now())
        #gym.logger.info("wasd 563.1: step_embedding_idxs: %s", step_embedding_idxs)
        #gym.logger.info("wasd 563.2: result: %s", result)

        if self.linear_layer is not None:
            assert self.activation_layer is not None, "Activation layer must be defined if linear layer is defined"

            result = self.linear_layer(result)
            result = self.activation_layer(result)

        return result

def create_mlp(
    input_dim: int,
    output_dim: int,
    net_arch: List[int],
    activation_fn: Type[nn.Module] = nn.ReLU,
    squash_output: bool = False,
    with_bias: bool = True,
    layer_norm_input: bool = False,
    layer_norm_before_activation: bool = False,
    dropout_p: float = 0.0,
    l2_norm: bool = False,
) -> List[nn.Module]:
    """
    Create a multi layer perceptron (MLP), which is
    a collection of fully-connected layers each followed by an activation function.

    :param input_dim: Dimension of the input vector
    :param output_dim:
    :param net_arch: Architecture of the neural net
        It represents the number of units per layer.
        The length of this list is the number of layers.
    :param activation_fn: The activation function
        to use after each layer.
    :param squash_output: Whether to squash the output using a Tanh
        activation function
    :param with_bias: If set to False, the layers will not learn an additive bias
    :return:
    """
    modules = []

    assert not (squash_output and l2_norm), "Both parameters cannot be enabled"

    if layer_norm_input:
        modules.append(nn.LayerNorm(input_dim, bias=with_bias))

    if len(net_arch) > 0:
        modules.append(nn.Linear(input_dim, net_arch[0], bias=with_bias))

        if dropout_p > 0.0: # linear + dropout + layernorm before activation = droq
            modules.append(nn.Dropout(p=dropout_p))

        if layer_norm_before_activation:
            modules.append(nn.LayerNorm(net_arch[0], bias=with_bias))

        modules.append(activation_fn())

    for idx in range(len(net_arch) - 1):
        modules.append(nn.Linear(net_arch[idx], net_arch[idx + 1], bias=with_bias))

        if dropout_p > 0.0:
            modules.append(nn.Dropout(p=dropout_p))

        if layer_norm_before_activation:
            modules.append(nn.LayerNorm(net_arch[idx + 1], bias=with_bias))

        modules.append(activation_fn())

    if output_dim > 0:
        last_layer_dim = net_arch[-1] if len(net_arch) > 0 else input_dim
        modules.append(nn.Linear(last_layer_dim, output_dim, bias=with_bias))

    if l2_norm:
        modules.append(L2Normalize())
    elif squash_output:
        modules.append(nn.Tanh())

    init_weights(modules) # other initialization are applied to specific layers somewhere else in the code

    return modules

def init_weights(modules, initializer_range=0.02):
    for module in modules:
        if isinstance(module, nn.Linear):
            # Slightly different from the TF version which uses truncated_normal for initialization
            # cf https://github.com/pytorch/pytorch/pull/5617
            module.weight.data.normal_(mean=0.0, std=initializer_range)
            if module.bias is not None:
                module.bias.data.zero_()
        elif isinstance(module, nn.Embedding):
            module.weight.data.normal_(mean=0.0, std=initializer_range)
            if module.padding_idx is not None:
                module.weight.data[module.padding_idx].zero_()
        elif isinstance(module, nn.LayerNorm):
            module.weight.data.fill_(1.0)
            if module.bias is not None:
                module.bias.data.zero_()
        #else:
        #    gym.logger.warn("Module not initialized: %s", module)

class MlpExtractor(nn.Module):
    """
    Constructs an MLP that receives the output from a previous features extractor (i.e. a CNN) or directly
    the observations (if no features extractor is applied) as an input and outputs a latent representation
    for the policy and a value network.

    The ``net_arch`` parameter allows to specify the amount and size of the hidden layers.
    It can be in either of the following forms:
    1. ``dict(vf=[<list of layer sizes>], pi=[<list of layer sizes>])``: to specify the amount and size of the layers in the
        policy and value nets individually. If it is missing any of the keys (pi or vf),
        zero layers will be considered for that key.
    2. ``[<list of layer sizes>]``: "shortcut" in case the amount and size of the layers
        in the policy and value nets are the same. Same as ``dict(vf=int_list, pi=int_list)``
        where int_list is the same for the actor and critic.

    .. note::
        If a key is not specified or an empty list is passed ``[]``, a linear network will be used.

    :param feature_dim: Dimension of the feature vector (can be the output of a CNN)
    :param net_arch: The specification of the policy and value networks.
        See above for details on its formatting.
    :param activation_fn: The activation function to use for the networks.
    :param device: PyTorch device.
    """

    def __init__(
        self,
        feature_dim: int,
        net_arch: Union[List[int], Dict[str, List[int]]],
        activation_fn: Type[nn.Module],
        device: Union[th.device, str] = "auto",
        layer_norm_input: bool = False,
        layer_norm_before_activation: bool = False,
    ) -> None:
        super().__init__()
        device = get_device(device)
        policy_net: List[nn.Module] = []
        value_net: List[nn.Module] = []
        last_layer_dim_pi = feature_dim
        last_layer_dim_vf = feature_dim

        if layer_norm_input:
            policy_net.append(nn.LayerNorm(last_layer_dim_pi))
            value_net.append(nn.LayerNorm(last_layer_dim_vf))

        # save dimensions of layers in policy and value nets
        if isinstance(net_arch, dict):
            # Note: if key is not specificed, assume linear network
            pi_layers_dims = net_arch.get("pi", [])  # Layer sizes of the policy network
            vf_layers_dims = net_arch.get("vf", [])  # Layer sizes of the value network
        else:
            pi_layers_dims = vf_layers_dims = net_arch

        empty_layers = net_arch.get("empty_layers", False) if isinstance(net_arch, dict) else False

        if empty_layers:
            assert len(pi_layers_dims) == 0, "If empty_layers is True, pi_layers_dims should be empty"
            assert len(vf_layers_dims) == 0, "If empty_layers is True, vf_layers_dims should be empty"
        else:
            assert len(pi_layers_dims) > 0 # Although this method supports empty lists, some scripts were passing the wrong format, and we should detect this situation
            assert len(vf_layers_dims) > 0 # Although this method supports empty lists, some scripts were passing the wrong format, and we should detect this situation

        # Iterate through the policy layers and build the policy net
        for curr_layer_dim in pi_layers_dims:
            policy_net.append(nn.Linear(last_layer_dim_pi, curr_layer_dim))

            if layer_norm_before_activation:
                policy_net.append(nn.LayerNorm(curr_layer_dim))

            policy_net.append(activation_fn())
            last_layer_dim_pi = curr_layer_dim
        # Iterate through the value layers and build the value net
        for curr_layer_dim in vf_layers_dims:
            value_net.append(nn.Linear(last_layer_dim_vf, curr_layer_dim))

            if layer_norm_before_activation:
                value_net.append(nn.LayerNorm(curr_layer_dim))

            value_net.append(activation_fn())
            last_layer_dim_vf = curr_layer_dim

        # Save dim, used to create the distributions
        self.latent_dim_pi = last_layer_dim_pi
        self.latent_dim_vf = last_layer_dim_vf

        # Create networks
        # If the list of layers is empty, the network will just act as an Identity module
        self.policy_net = nn.Sequential(*policy_net).to(device)
        self.value_net = nn.Sequential(*value_net).to(device)

    def forward(self, features: th.Tensor) -> Tuple[th.Tensor, th.Tensor]:
        """
        :return: latent_policy, latent_value of the specified network.
            If all layers are shared, then ``latent_policy == latent_value``
        """
        return self.forward_actor(features), self.forward_critic(features)

    def forward_actor(self, features: th.Tensor) -> th.Tensor:
        return self.policy_net(features)

    def forward_critic(self, features: th.Tensor) -> th.Tensor:
        return self.value_net(features)


class CombinedExtractor(BaseFeaturesExtractor):
    """
    Combined features extractor for Dict observation spaces.
    Builds a features extractor for each key of the space. Input from each space
    is fed through a separate submodule (CNN or MLP, depending on input shape),
    the output features are concatenated and fed through additional MLP network ("combined").

    :param observation_space:
    :param cnn_output_dim: Number of features to output from each CNN submodule(s). Defaults to
        256 to avoid exploding network sizes.
    :param normalized_image: Whether to assume that the image is already normalized
        or not (this disables dtype and bounds checks): when True, it only checks that
        the space is a Box and has 3 dimensions.
        Otherwise, it checks that it has expected dtype (uint8) and bounds (values in [0, 255]).
    """

    def __init__(
        self,
        observation_space: spaces.Dict,
        cnn_output_dim: int = 256,
        normalized_image: bool = False,
    ) -> None:
        # TODO we do not know features-dim here before going over all the items, so put something there. This is dirty!
        super().__init__(observation_space, features_dim=1)

        extractors: Dict[str, nn.Module] = {}

        total_concat_size = 0
        for key, subspace in observation_space.spaces.items():
            if is_image_space(subspace, normalized_image=normalized_image):
                extractors[key] = NatureCNN(subspace, features_dim=cnn_output_dim, normalized_image=normalized_image)
                total_concat_size += cnn_output_dim
            else:
                # The observation key is a vector, flatten it if needed
                extractors[key] = nn.Flatten()
                total_concat_size += get_flattened_obs_dim(subspace)

        self.extractors = nn.ModuleDict(extractors)

        # Update the features dim manually
        self._features_dim = total_concat_size

    def forward(self, observations: TensorDict) -> th.Tensor:
        encoded_tensor_list = []

        for key, extractor in self.extractors.items():
            encoded_tensor_list.append(extractor(observations[key]))
        return th.cat(encoded_tensor_list, dim=1)


def get_actor_critic_arch(net_arch: Union[List[int], Dict[str, List[int]]]) -> Tuple[List[int], List[int]]:
    """
    Get the actor and critic network architectures for off-policy actor-critic algorithms (SAC, TD3, DDPG).

    The ``net_arch`` parameter allows to specify the amount and size of the hidden layers,
    which can be different for the actor and the critic.
    It is assumed to be a list of ints or a dict.

    1. If it is a list, actor and critic networks will have the same architecture.
        The architecture is represented by a list of integers (of arbitrary length (zero allowed))
        each specifying the number of units per layer.
       If the number of ints is zero, the network will be linear.
    2. If it is a dict,  it should have the following structure:
       ``dict(qf=[<critic network architecture>], pi=[<actor network architecture>])``.
       where the network architecture is a list as described in 1.

    For example, to have actor and critic that share the same network architecture,
    you only need to specify ``net_arch=[256, 256]`` (here, two hidden layers of 256 units each).

    If you want a different architecture for the actor and the critic,
    then you can specify ``net_arch=dict(qf=[400, 300], pi=[64, 64])``.

    .. note::
        Compared to their on-policy counterparts, no shared layers (other than the features extractor)
        between the actor and the critic are allowed (to prevent issues with target networks).

    :param net_arch: The specification of the actor and critic networks.
        See above for details on its formatting.
    :return: The network architectures for the actor and the critic
    """
    if isinstance(net_arch, list):
        actor_arch, critic_arch = net_arch, net_arch
    else:
        assert isinstance(net_arch, dict), "Error: the net_arch can only contain be a list of ints or a dict"
        assert "pi" in net_arch, "Error: no key 'pi' was provided in net_arch for the actor network"
        assert "qf" in net_arch, "Error: no key 'qf' was provided in net_arch for the critic network"
        actor_arch, critic_arch = net_arch["pi"], net_arch["qf"]
    return actor_arch, critic_arch
