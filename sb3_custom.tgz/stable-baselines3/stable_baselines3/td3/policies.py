from typing import Any, Dict, List, Optional, Type, Union, Tuple, Callable
import inspect
import datetime
from functools import partial

import torch as th
from gymnasium import spaces
from torch import nn
import numpy as np
import gymnasium as gym

from stable_baselines3.common.noise import ActionNoise
from stable_baselines3.common.policies import BasePolicy, ContinuousCritic, ContinuousCriticTower
from stable_baselines3.common.preprocessing import get_action_dim
from stable_baselines3.common.torch_layers import (
    BaseFeaturesExtractor,
    CombinedExtractor,
    FlattenExtractor,
    NatureCNN,
    create_mlp,
    get_actor_critic_arch,
    NoFlattenExtractor,
    TransformerExtractor,
)
from stable_baselines3.common.type_aliases import PyTorchObs, Schedule


class Actor(BasePolicy):
    """
    Actor network (policy) for TD3.

    :param observation_space: Obervation space
    :param action_space: Action space
    :param net_arch: Network architecture
    :param features_extractor: Network to extract features
        (a CNN when using images, a nn.Flatten() layer otherwise)
    :param features_dim: Number of features
    :param activation_fn: Activation function
    :param normalize_images: Whether to normalize images or not,
         dividing by 255.0 (True by default)
    """

    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        net_arch: List[int],
        features_extractor: nn.Module,
        features_dim: int,
        activation_fn: Type[nn.Module] = nn.ReLU,
        normalize_images: bool = True,
        actor_layer_norm_input: bool = False,
        actor_layer_norm_before_activation: bool = False,
        actor_dropout_p: float = 0.0,
        squash_output: bool = True,
        actor_mlp_l2_norm: bool = False,
    ):
        super().__init__(
            observation_space,
            action_space,
            features_extractor=features_extractor,
            normalize_images=normalize_images,
            squash_output=squash_output,
        )

        self.net_arch = net_arch
        self.features_dim = features_dim
        self.activation_fn = activation_fn
        self.actor_layer_norm_input = actor_layer_norm_input
        self.actor_layer_norm_before_activation = actor_layer_norm_before_activation
        self.actor_dropout_p = actor_dropout_p
        self.actor_mlp_l2_norm = actor_mlp_l2_norm

        #action_dim = get_action_dim(self.action_space)
        #actor_net = create_mlp(features_dim, action_dim, net_arch, activation_fn, squash_output=True)
        self.action_dim = get_action_dim(self.action_space)
        actor_net = create_mlp(features_dim, self.action_dim, net_arch, activation_fn, squash_output=squash_output,
                               layer_norm_input=actor_layer_norm_input, layer_norm_before_activation=actor_layer_norm_before_activation,
                               dropout_p=actor_dropout_p, l2_norm=actor_mlp_l2_norm)
        # Deterministic action
        self.mu = nn.Sequential(*actor_net)

    def _get_constructor_parameters(self) -> Dict[str, Any]:
        data = super()._get_constructor_parameters()

        data.update(
            dict(
                net_arch=self.net_arch,
                features_dim=self.features_dim,
                activation_fn=self.activation_fn,
                features_extractor=self.features_extractor,
                actor_layer_norm_input=self.actor_layer_norm_input,
                actor_layer_norm_before_activation=self.actor_layer_norm_before_activation,
                actor_dropout_p=self.actor_dropout_p,
                actor_mlp_l2_norm=self.actor_mlp_l2_norm
            )
        )
        return data

    def forward(self, obs: th.Tensor, model_kwargs: Optional[Dict] = {}) -> th.Tensor:
        # assert deterministic, 'The TD3 actor only outputs deterministic actions'
        features = self.extract_features(obs, self.features_extractor, model_kwargs=model_kwargs)
        return self.mu(features)

    def _predict(self, observation: PyTorchObs, deterministic: bool = False) -> th.Tensor:
        # Note: the deterministic deterministic parameter is ignored in the case of TD3.
        #   Predictions are always deterministic.
        return self(observation)

class DummyActor(BasePolicy):
    """
    Dummy actor that returns zero or gaussian distribution.
    """

    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        net_arch: List[int],
        features_extractor: nn.Module,
        features_dim: int,
        activation_fn: Type[nn.Module] = nn.ReLU,
        normalize_images: bool = True,
        squash_output: bool = True,
        zero_distribution: bool = True,
        gaussian_mean=0.0,
        gaussian_std=0.5,
        **kwargs, # ignored
    ):
        super().__init__(
            observation_space,
            action_space,
            features_extractor=features_extractor,
            normalize_images=normalize_images,
            squash_output=squash_output,
        )

        self.net_arch = net_arch
        self.features_dim = features_dim
        self.activation_fn = activation_fn
        self.action_dim = get_action_dim(self.action_space) # output_dim
        self.zero_distribution = zero_distribution
        self.gaussian_mean = gaussian_mean
        self.gaussian_std = gaussian_std

        assert self.action_dim > 0, f"Invalid action_dim: {self.action_dim}"

    def _get_constructor_parameters(self) -> Dict[str, Any]:
        data = super()._get_constructor_parameters()

        data.update(
            dict(
                net_arch=self.net_arch,
                features_dim=self.features_dim,
                activation_fn=self.activation_fn,
                features_extractor=self.features_extractor,
                zero_distribution=self.zero_distribution,
                gaussian_mean=self.gaussian_mean,
                gaussian_std=self.gaussian_std,
            )
        )
        return data

    def forward(self, obs: th.Tensor, model_kwargs: Optional[Dict] = {}) -> th.Tensor:
        assert len(obs.shape) == 2, obs.shape

        bsz = obs.shape[0]
        size = (bsz, self.action_dim)

        if self.zero_distribution:
            return th.zeros(size=size, device=obs.device, dtype=obs.dtype)

        return th.normal(mean=self.gaussian_mean, std=self.gaussian_std, size=size, device=obs.device, dtype=obs.dtype)

    def _predict(self, observation: PyTorchObs, deterministic: bool = False) -> th.Tensor:
        return self(observation)

def create_group_parameters(module, weight_decay=0.0):
    # It is common to avoid decay to specfic parameters:
    ## https://github.com/huggingface/transformers/blob/7c6cd0ac28f1b760ccb4d6e4761f13185d05d90b/src/transformers/trainer.py#L802
    ## https://www.towardsdeeplearning.com/adamw-the-quiet-goat-why-it-still-powers-todays-largest-llms-b377791e7acf
    ## https://github.com/karpathy/minGPT/blob/3ed14b2cec0dfdad3f4b2831f2b4a86d11aef150/mingpt/model.py#L149
    #decay_params = []
    #no_decay_params = []
    decay = set()
    no_decay = set()

    assert hasattr(module, "parameters"), module

    if weight_decay is None:
        return module.parameters()

#    for name, param in parameters.named_parameters():
#        if not param.requires_grad:
#            continue
#
#        # Always exclude biases
#        if 'bias' in name:
#            no_decay_params.append(param)
#        # Exclude LayerNorm weights/scale
#        elif 'norm' in name or 'ln' in name:
#            no_decay_params.append(param)
#        # Include standard weights
#        else:
#            decay_params.append(param)

    whitelist_weight_modules = (th.nn.Linear, th.nn.MultiheadAttention)
    blacklist_weight_modules = (th.nn.LayerNorm, th.nn.Embedding)
    seen_param_ids = set()

    for mn, m in module.named_modules():
        # CASE A: Whitelist Modules (Linear, Attention)
        if isinstance(m, whitelist_weight_modules):
            for pn, p in m.named_parameters():
                if id(p) in seen_param_ids:
                    continue

                fpn = '%s.%s' % (mn, pn) if mn else pn

                if pn.endswith('bias'):
                    no_decay.add(fpn)
                else:
                    decay.add(fpn) # Weights get decay

                seen_param_ids.add(id(p))

        # CASE B: Blacklist Modules (LayerNorm, Embedding)
        elif isinstance(m, blacklist_weight_modules):
            for pn, p in m.named_parameters():
                if id(p) in seen_param_ids:
                    continue

                fpn = '%s.%s' % (mn, pn) if mn else pn

                no_decay.add(fpn) # Everything gets no_decay
                seen_param_ids.add(id(p))

    for pn, p in module.named_parameters():
        if id(p) in seen_param_ids:
            continue

        # Fallback logic for parameters not inside standard layers
        if 'bias' in pn:
            no_decay.add(pn)
        elif 'norm' in pn or 'ln' in pn:
            no_decay.add(pn)
        elif 'embed' in pn:
            no_decay.add(pn)
        else:
            decay.add(pn)
            print(f"Caught orphaned param: {pn} -> decay")

        seen_param_ids.add(id(p))

    print(f"Decay: {decay}")
    print(f"No decay: {no_decay}")

    # validate that we considered every parameter
    param_dict = {pn: p for pn, p in module.named_parameters()}
    inter_params = decay & no_decay
    union_params = decay | no_decay
    assert len(inter_params) == 0, "parameters %s made it into both decay/no_decay sets!" % (str(inter_params), )
    assert len(param_dict.keys() - union_params) == 0, "parameters %s were not separated into either decay/no_decay set!" % (str(param_dict.keys() - union_params), )

    # Create parameter groups
#    optim_groups = [
#        {'params': decay_params, 'weight_decay': weight_decay},
#        {'params': no_decay_params, 'weight_decay': 0.0}
#    ]
    optim_groups = [
        {"params": [param_dict[pn] for pn in sorted(list(decay))], "weight_decay": weight_decay},
        {"params": [param_dict[pn] for pn in sorted(list(no_decay))], "weight_decay": 0.0},
    ]

    return optim_groups


class TD3Policy(BasePolicy):
    """
    Policy class (with both actor and critic) for TD3.

    :param observation_space: Observation space
    :param action_space: Action space
    :param lr_schedule: Learning rate schedule (could be constant)
    :param net_arch: The specification of the policy and value networks.
    :param activation_fn: Activation function
    :param features_extractor_class: Features extractor to use.
    :param features_extractor_kwargs: Keyword arguments
        to pass to the features extractor.
    :param normalize_images: Whether to normalize images or not,
         dividing by 255.0 (True by default)
    :param optimizer_class: The optimizer to use,
        ``th.optim.Adam`` by default
    :param optimizer_kwargs: Additional keyword arguments,
        excluding the learning rate, to pass to the optimizer
    :param n_critics: Number of critic networks to create.
    :param share_features_extractor: Whether to share or not the features extractor
        between the actor and the critic (this saves computation time)
    """

    actor: Actor
    actor_target: Actor
    critic: ContinuousCritic
    critic_target: ContinuousCritic

    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        lr_schedule: Schedule,
        net_arch: Optional[Union[List[int], Dict[str, List[int]]]] = None,
        activation_fn: Type[nn.Module] = nn.ReLU,
        features_extractor_class: Type[BaseFeaturesExtractor] = FlattenExtractor,
        features_extractor_kwargs: Optional[Dict[str, Any]] = None,
        normalize_images: bool = True,
        optimizer_class: Type[th.optim.Optimizer] = th.optim.Adam,
        optimizer_kwargs: Optional[Dict[str, Any]] = None,
        n_critics: int = 2,
        share_features_extractor: bool = False,
        actor_lr_schedule: Optional[Schedule] = None,
        actor_layer_norm_input: bool = False,
        actor_layer_norm_before_activation: bool = False,
        actor_last_layer_init_uniform_value: Optional[float] = None,
        actor_dropout_p: float = 0.0,
        actor_mlp_l2_norm: bool = False,
        squash_output: bool = True,
        critic_layer_norm_input: bool = False,
        critic_layer_norm_before_activation: bool = False,
        critic_last_layer_init_uniform_value: Optional[float] = None,
        critic_dropout_p: float = 0.0,
        critic_first_actions_then_features: bool = False,
        features_extractor_kwargs_actor: Optional[Dict[str, Any]] = None,
        features_extractor_kwargs_critic: Optional[Dict[str, Any]] = None,
        wolpertinger_disable_actor: bool = False,
        critic_action_layer_norm_input: bool = False,
        critic_features_layer_norm_input: bool = False,
        critic_action_layer_dropout: float = 0.0,
        critic_action_linear_layer_projection: int = 0,
        critic_features_linear_layer_projection: int = 0,
        ortho_init: bool = True,
        critic_class = None,
    ):
        super().__init__(
            observation_space,
            action_space,
            features_extractor_class,
            features_extractor_kwargs,
            optimizer_class=optimizer_class,
            optimizer_kwargs=optimizer_kwargs,
            squash_output=squash_output,
            normalize_images=normalize_images,
        )

        if features_extractor_kwargs_actor is None:
            features_extractor_kwargs_actor = {}

        if features_extractor_kwargs_critic is None:
            features_extractor_kwargs_critic = {}

        self.features_extractor_kwargs_actor = features_extractor_kwargs_actor
        self.features_extractor_kwargs_critic = features_extractor_kwargs_critic

        # Default network architecture, from the original paper
        if net_arch is None:
            if features_extractor_class == NatureCNN:
                net_arch = [256, 256]
            else:
                net_arch = [400, 300]

        actor_arch, critic_arch = get_actor_critic_arch(net_arch)

        self.actor_layer_norm_input = actor_layer_norm_input
        self.actor_layer_norm_before_activation = actor_layer_norm_before_activation
        self.actor_last_layer_init_uniform_value = actor_last_layer_init_uniform_value
        self.actor_dropout_p = actor_dropout_p
        self.actor_mlp_l2_norm = actor_mlp_l2_norm
        self.critic_layer_norm_input = critic_layer_norm_input
        self.critic_layer_norm_before_activation = critic_layer_norm_before_activation
        self.critic_last_layer_init_uniform_value = critic_last_layer_init_uniform_value
        self.critic_dropout_p = critic_dropout_p
        self.critic_first_actions_then_features = critic_first_actions_then_features
        self.wolpertinger_disable_actor = wolpertinger_disable_actor
        self.critic_action_layer_norm_input = critic_action_layer_norm_input
        self.critic_features_layer_norm_input = critic_features_layer_norm_input
        self.critic_action_layer_dropout = critic_action_layer_dropout
        self.critic_action_linear_layer_projection = critic_action_linear_layer_projection
        self.critic_features_linear_layer_projection = critic_features_linear_layer_projection
        self.ortho_init = ortho_init
        self.critic_class = critic_class

        self.net_arch = net_arch
        self.activation_fn = activation_fn
        self.net_args = {
            "observation_space": self.observation_space,
            "action_space": self.action_space,
            "net_arch": actor_arch,
            "activation_fn": self.activation_fn,
            "normalize_images": normalize_images,
        }
        self.actor_kwargs = self.net_args.copy()
        self.critic_kwargs = self.net_args.copy()
        self.critic_kwargs.update(
            {
                "n_critics": n_critics,
                "net_arch": critic_arch,
                "share_features_extractor": share_features_extractor,
            }
        )

        gym.logger.info("n_critics: %d", n_critics)

        # actor
        if self.wolpertinger_disable_actor:
            assert not share_features_extractor, "The actor is the one who updates the features extractor, so it cannot be shared if wolpertinger_disable_actor is True"

        if actor_layer_norm_input:
            self.actor_kwargs["actor_layer_norm_input"] = actor_layer_norm_input

            gym.logger.info("Adding layer norm input to actor")

        if actor_layer_norm_before_activation:
            self.actor_kwargs["actor_layer_norm_before_activation"] = actor_layer_norm_before_activation

            gym.logger.info("Adding layer norm before activation to actor")

        if actor_dropout_p > 0.0:
            self.actor_kwargs["actor_dropout_p"] = actor_dropout_p

            gym.logger.info("Adding dropout to actor with p=%f", actor_dropout_p)

        assert "actor_mlp_l2_norm" not in self.actor_kwargs, self.actor_kwargs

        self.actor_kwargs["actor_mlp_l2_norm"] = self.actor_mlp_l2_norm
        self.actor_kwargs["wolpertinger_disable_actor"] = self.wolpertinger_disable_actor

        if self.actor_mlp_l2_norm:
            gym.logger.info("Using MLP l2-normalization")

        # critic
        if critic_features_layer_norm_input:
            self.critic_kwargs["critic_features_layer_norm_input"] = critic_features_layer_norm_input

            gym.logger.info("Adding layer norm to critic features input")

        if critic_action_layer_norm_input:
            self.critic_kwargs["critic_action_layer_norm_input"] = critic_action_layer_norm_input

            gym.logger.info("Adding layer norm to critic action input")

        if critic_action_layer_dropout > 0.0:
            self.critic_kwargs["critic_action_layer_dropout"] = critic_action_layer_dropout

            gym.logger.info("Adding dropout to critic action input")

        if critic_action_linear_layer_projection > 0:
            self.critic_kwargs["critic_action_linear_layer_projection"] = critic_action_linear_layer_projection

            gym.logger.info("Adding linear layer projection to critic action input")

        if critic_features_linear_layer_projection > 0:
            self.critic_kwargs["critic_features_linear_layer_projection"] = critic_features_linear_layer_projection

            gym.logger.info("Adding linear layer projection to critic features input")

        if critic_layer_norm_input:
            self.critic_kwargs["critic_layer_norm_input"] = critic_layer_norm_input

            gym.logger.info("Adding layer norm input to critic")

        if critic_layer_norm_before_activation:
            self.critic_kwargs["critic_layer_norm_before_activation"] = critic_layer_norm_before_activation

            gym.logger.info("Adding layer norm before activation to critic")

        if critic_dropout_p > 0.0:
            self.critic_kwargs["critic_dropout_p"] = critic_dropout_p

            gym.logger.info("Adding dropout to critic with p=%f", critic_dropout_p)

        self.critic_kwargs["critic_first_actions_then_features"] = critic_first_actions_then_features

        # finish
        self.actor_kwargs["squash_output"] = squash_output # "def predict" clips the output when squash_output=False
        self.share_features_extractor = share_features_extractor
        _lr_schedule = lr_schedule if actor_lr_schedule is None else {"actor": actor_lr_schedule, "critic": lr_schedule}

        self._build(_lr_schedule)

    def _build(self, lr_schedule: Union[Schedule, Dict[str, Schedule]]) -> None:
        # Create actor and target
        # the features extractor should not be shared
        self.actor = self.make_actor(features_extractor=None if not self.wolpertinger_disable_actor else FlattenExtractor(self.observation_space))
        self.actor_target = self.make_actor(features_extractor=None if not self.wolpertinger_disable_actor else FlattenExtractor(self.observation_space))

        if self.ortho_init:
            # TODO: check for features_extractor
            # Values from stable-baselines.
            # features_extractor/mlp values are
            # originally from openai/baselines (default gains/init_scales).
            self.actor.apply(partial(self.init_weights, gain=np.sqrt(2)))

        if isinstance(self.actor.features_extractor, TransformerExtractor):
            gym.logger.info("actor transformer init")
            self.actor.features_extractor.transformer.init_weights()

        if not self.wolpertinger_disable_actor and self.actor_last_layer_init_uniform_value is not None:
            if self.squash_output:
                assert self.actor.mu[-1].__module__ == "torch.nn.modules.activation", self.actor.mu[-1].__module__
                assert self.actor.mu[-2].__module__ == "torch.nn.modules.linear", self.actor.mu[-2].__module__
            elif self.actor_mlp_l2_norm:
                assert self.actor.mu[-1].__module__ == "stable_baselines3.common.transformer_layers", self.actor.mu[-1].__module__ # L2Normalize()
                assert self.actor.mu[-2].__module__ == "torch.nn.modules.linear", self.actor.mu[-2].__module__
            else:
                assert self.actor.mu[-1].__module__ == "torch.nn.modules.linear", self.actor.mu[-1].__module__

            layer = self.actor.mu[-2 if self.squash_output or self.actor_mlp_l2_norm else -1]

            nn.init.uniform_(layer.weight, -self.actor_last_layer_init_uniform_value, self.actor_last_layer_init_uniform_value)

            if hasattr(layer, "bias") and layer.bias is not None:
                nn.init.constant_(layer.bias, 0)

        # Initialize the target to have the same weights as the actor
        self.actor_target.load_state_dict(self.actor.state_dict())

        if isinstance(lr_schedule, dict):
            assert "actor" in lr_schedule and "critic" in lr_schedule, lr_schedule.keys()

        self.actor_lr_schedule  = lr_schedule["actor"] if isinstance(lr_schedule, dict) else lr_schedule
        self.critic_lr_schedule = lr_schedule["critic"] if isinstance(lr_schedule, dict) else lr_schedule

        gym.logger.info("Actor and critic learning rate: %f %f", self.actor_lr_schedule(1), self.critic_lr_schedule(1))

        # TODO remove?
        #import copy
        #asd = copy.deepcopy(self.actor.mu[-2].weight)
        #assert (asd == self.actor.mu[-2].weight).all().item()
        #nn.init.uniform_(self.actor.mu[-2].weight, -0.001, 0.001)
        #assert (asd != self.actor.mu[-2].weight).all().item()
        #nn.init.uniform_(self.actor_target.mu[-2].weight, -0.001, 0.001)
        # TODO remove?

        assert isinstance(self.optimizer_kwargs, dict), type(self.optimizer_kwargs)

        optimizer_kwargs = dict(self.optimizer_kwargs)
        weight_decay = optimizer_kwargs.pop("weight_decay", None)

        if weight_decay is None:
            sign = inspect.signature(self.optimizer_class)

            if "weight_decay" in sign.parameters:
                weight_decay = sign.parameters["weight_decay"].default

        gym.logger.info("weight_decay: %s", weight_decay)

        actor_parameter_groups = []

        self.actor.optimizer = self.optimizer_class(
            create_group_parameters(self.actor, weight_decay=weight_decay),
            lr=self.actor_lr_schedule(1),  # type: ignore[call-arg]
            **optimizer_kwargs,
        )

        if self.share_features_extractor:
            self.critic = self.make_critic(features_extractor=self.actor.features_extractor)
            # Critic target should not share the features extractor with critic
            # but it can share it with the actor target as actor and critic are sharing
            # the same features_extractor too
            # NOTE: as a result the effective polyak (soft-copy) coefficient for the features extractor
            # will be 2 * tau instead of tau (updated one time with the actor, a second time with the critic)
            self.critic_target = self.make_critic(features_extractor=self.actor_target.features_extractor)
        else:
            # Create new features extractor for each network
            self.critic = self.make_critic(features_extractor=None)
            self.critic_target = self.make_critic(features_extractor=None)

        if self.ortho_init:
            # TODO: check for features_extractor
            # Values from stable-baselines.
            # features_extractor/mlp values are
            # originally from openai/baselines (default gains/init_scales).
            self.critic.apply(partial(self.init_weights, gain=np.sqrt(2)))

            if isinstance(self.critic, ContinuousCriticTower):
                all_q_nets = (self.critic.q_networks_state, self.critic.q_networks_action)
            else:
                all_q_nets = (self.critic.q_networks,)

            for q_nets in all_q_nets:
                for q_net in q_nets:
                    assert isinstance(q_net, nn.Sequential)

                    layer = q_net[-1]

                    assert isinstance(layer, nn.Linear), layer

                    layer.apply(partial(self.init_weights, gain=1.0))

        if isinstance(self.critic.features_extractor, TransformerExtractor):
            gym.logger.info("critic transformer init")
            self.critic.features_extractor.transformer.init_weights()

        if self.critic_last_layer_init_uniform_value is not None:
            for q_net in self.critic.q_networks:
                assert isinstance(q_net, nn.Sequential)

                layer = q_net[-1]

                assert isinstance(layer, nn.Linear), layer

                nn.init.uniform_(layer.weight, -self.critic_last_layer_init_uniform_value, self.critic_last_layer_init_uniform_value)

                if hasattr(layer, "bias") and layer.bias is not None:
                    nn.init.constant_(layer.bias, 0)

        self.critic_target.load_state_dict(self.critic.state_dict())
        self.critic.optimizer = self.optimizer_class(
            create_group_parameters(self.critic, weight_decay=weight_decay),
            lr=self.critic_lr_schedule(1),  # type: ignore[call-arg]
            **optimizer_kwargs,
        )

        # Target networks should always be in eval mode
        self.actor_target.set_training_mode(False)
        self.critic_target.set_training_mode(False)

    def _get_constructor_parameters(self) -> Dict[str, Any]:
        data = super()._get_constructor_parameters()

        data.update(
            dict(
                net_arch=self.net_arch,
                activation_fn=self.net_args["activation_fn"],
                n_critics=self.critic_kwargs["n_critics"],
                lr_schedule=self._dummy_schedule,  # dummy lr schedule, not needed for loading policy alone
                optimizer_class=self.optimizer_class,
                optimizer_kwargs=self.optimizer_kwargs,
                features_extractor_class=self.features_extractor_class,
                features_extractor_kwargs=self.features_extractor_kwargs,
                share_features_extractor=self.share_features_extractor,
                actor_lr_schedule=self._dummy_schedule,
                actor_layer_norm_input=self.actor_layer_norm_input,
                actor_layer_norm_before_activation=self.actor_layer_norm_before_activation,
                actor_last_layer_init_uniform_value=self.actor_last_layer_init_uniform_value,
                actor_dropout_p=self.actor_dropout_p,
                actor_mlp_l2_norm=self.actor_mlp_l2_norm,
                critic_layer_norm_input=self.critic_layer_norm_input,
                critic_layer_norm_before_activation=self.critic_layer_norm_before_activation,
                critic_last_layer_init_uniform_value=self.critic_last_layer_init_uniform_value,
                critic_dropout_p=self.critic_dropout_p,
                critic_first_actions_then_features=self.critic_first_actions_then_features,
                features_extractor_kwargs_actor=self.features_extractor_kwargs_actor,
                features_extractor_kwargs_critic=self.features_extractor_kwargs_critic,
                wolpertinger_disable_actor=self.wolpertinger_disable_actor,
                critic_action_layer_norm_input=self.critic_action_layer_norm_input,
                critic_features_layer_norm_input=self.critic_features_layer_norm_input,
                critic_action_layer_dropout=self.critic_action_layer_dropout,
                critic_action_linear_layer_projection=self.critic_action_linear_layer_projection,
                critic_features_linear_layer_projection=self.critic_features_linear_layer_projection,
                ortho_init=self.ortho_init,
                critic_class=self.critic_class,
            )
        )
        return data

    def _update_features_extractor(
        self,
        net_kwargs: Dict[str, Any],
        features_extractor: Optional[BaseFeaturesExtractor] = None,
        features_extractor_kwargs: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Update the network keyword arguments and create a new features extractor object if needed.
        If a ``features_extractor`` object is passed, then it will be shared.

        :param net_kwargs: the base network keyword arguments, without the ones
            related to features extractor
        :param features_extractor: a features extractor object.
            If None, a new object will be created.
        :return: The updated keyword arguments
        """
        net_kwargs = net_kwargs.copy()
        if features_extractor is None:
            # The features extractor is not shared, create a new one
            features_extractor = self.make_features_extractor(kwargs=features_extractor_kwargs)
        net_kwargs.update(dict(features_extractor=features_extractor, features_dim=features_extractor.features_dim))
        return net_kwargs

    def make_features_extractor(self, kwargs: Optional[Dict[str, Any]] = None) -> BaseFeaturesExtractor:
        """Helper method to create a features extractor."""
        if kwargs is None or len(kwargs) == 0:
            kwargs = self.features_extractor_kwargs

        return self.features_extractor_class(self.observation_space, **kwargs)

    def make_actor(self, features_extractor: Optional[BaseFeaturesExtractor] = None) -> Actor:
        actor_kwargs = self._update_features_extractor(self.actor_kwargs, features_extractor, features_extractor_kwargs=self.features_extractor_kwargs_actor)

        if self.wolpertinger_disable_actor:
            return DummyActor(**actor_kwargs).to(self.device)

        return Actor(**actor_kwargs).to(self.device)

    def make_critic(self, features_extractor: Optional[BaseFeaturesExtractor] = None) -> ContinuousCritic:
        critic_kwargs = self._update_features_extractor(self.critic_kwargs, features_extractor, features_extractor_kwargs=self.features_extractor_kwargs_critic)
        _cls = ContinuousCritic if self.critic_class is None else self.critic_class
        return _cls(**critic_kwargs).to(self.device)

    def forward(self, observation: PyTorchObs, deterministic: bool = False) -> th.Tensor:
        return self._predict(observation, deterministic=deterministic)

    def _predict(self, observation: PyTorchObs, deterministic: bool = False) -> th.Tensor:
        # Note: the deterministic deterministic parameter is ignored in the case of TD3.
        #   Predictions are always deterministic.
        return self.actor(observation)

    def set_training_mode(self, mode: bool) -> None:
        """
        Put the policy in either training or evaluation mode.

        This affects certain modules, such as batch normalisation and dropout.

        :param mode: if true, set to training mode, else set to evaluation mode
        """
        self.actor.set_training_mode(mode)
        self.critic.set_training_mode(mode)
        self.training = mode


MlpPolicy = TD3Policy

#asd = [] # TODO remove

class WolpertingerPolicy(TD3Policy):

    #def __init__(self, *args, callback_retrieve_knn, embedding_size, k=0.1, **kwargs):
    def __init__(self, *args, callback_retrieve_knn=None, callback_retrieve_knn_training=None, k=0.1, add_all_knn_to_batch=1,
                 apply_rws_inference=False, exploration_rate=0.1, skip_n_word_embeddings_transformer_from_observation=0, **kwargs):
        super().__init__(*args, **kwargs)

        n_critics = self.critic.n_critics

        assert callback_retrieve_knn is not None, "callback_retrieve_knn kwarg is mandatory"
        #assert n_critics == 1, f"Expected n_critics was 1, but got {n_critics} (only DDPG is supported)"

        self.actor_input_size, self.actor_output_size = self.actor.features_dim, self.actor.action_dim
        self.callback_retrieve_knn = callback_retrieve_knn # args: embedding, k
        self.callback_retrieve_knn_training = callback_retrieve_knn_training # args: same that self.callback_retrieve_knn
        #self.embedding_size = embedding_size
        self.k = k
        self.knn_percentage = isinstance(self.k, float)
        self.apply_rws_inference = apply_rws_inference
        self.n_critics = n_critics
        self.exploration_rate = exploration_rate
        self.skip_n_word_embeddings_transformer_from_observation = skip_n_word_embeddings_transformer_from_observation

        #assert 0 <= self.exploration_rate < 1, self.exploration_rate
        assert self.skip_n_word_embeddings_transformer_from_observation >= 0, self.skip_n_word_embeddings_transformer_from_observation

        if self.knn_percentage:
            min_k_percentage = 0.0001 # 0.01%

            assert min_k_percentage <= self.k <= 1.0, f"k={self.k} is not in [{min_k_percentage}, 1.0]"
        else:
            assert self.k >= 1, f"k={self.k} cannot be < 1"

        self.add_all_knn_to_batch = max(1, add_all_knn_to_batch) # actual batch_size will be retrieved_knn * batch_size

        if self.callback_retrieve_knn_training is None:
            self.callback_retrieve_knn_training = callback_retrieve_knn

    def roulette_wheel_selection(self, population, fitness_scores):
        population = population.detach().cpu().numpy()
        fitness_scores = fitness_scores.detach().cpu().numpy()

        assert len(fitness_scores.shape) == 3
        assert len(population.shape) == 3
        assert fitness_scores.shape[0] == population.shape[0] # batch_size
        assert fitness_scores.shape[1] <= self.k if not self.knn_percentage else True # k
        assert fitness_scores.shape[2] == 1 # Q value
        assert population.shape[1] <= self.k if not self.knn_percentage else True # k
        assert population.shape[2] == self.actor_output_size # action_space

        batch_size = fitness_scores.shape[0]
        result = []

        #total_fitness = sum(fitness_scores)
        total_fitness = np.sum(fitness_scores, axis=1) # (batch_size, 1)
        relative_fitness = np.array([f / t for f, t in zip(fitness_scores, total_fitness)]) # (batch_size, k, 1)
        cumulative_probability = np.array([sum(relative_fitness[i][:j+1]) for i in range(len(relative_fitness)) for j in range(len(relative_fitness[i]))]).reshape(relative_fitness.shape)

        for batch in range(batch_size):
            result.append([])

            rand = np.random.random()

            for i, cp in enumerate(cumulative_probability[batch]):
                cp = cp[0]

                if rand <= cp:
                    result[-1].append(population[batch][i])
                    break

        result = np.squeeze(np.array(result), axis=1)

        assert len(result.shape) == 2
        assert result.shape[0] == batch_size
        assert result.shape[1] == self.actor_output_size

        return result

    def predict(
        self,
        observation: Union[np.ndarray, Dict[str, np.ndarray]],
        state: Optional[Tuple[np.ndarray, ...]] = None,
        episode_start: Optional[np.ndarray] = None,
        deterministic: bool = False,
        action_noise: Optional[ActionNoise] = None,
        knn_callback: Optional[Callable] = None,
        time_steps: Optional[List[int]] = None,
        env = None,
    ) -> Tuple[np.ndarray, Optional[Tuple[np.ndarray, ...]]]:
        """
        Code from BasePolicy with modifications for the Wolpertinger policy.
        """
        # Switch to eval mode (this affects batch norm / dropout)
        self.set_training_mode(False)

        # Check for common mistake that the user does not mix Gym/VecEnv API
        # Tuple obs are not supported by SB3, so we can safely do that check
        if isinstance(observation, tuple) and len(observation) == 2 and isinstance(observation[1], dict):
            raise ValueError(
                "You have passed a tuple to the predict() function instead of a Numpy array or a Dict. "
                "You are probably mixing Gym API with SB3 VecEnv API: `obs, info = env.reset()` (Gym) "
                "vs `obs = vec_env.reset()` (SB3 VecEnv). "
                "See related issue https://github.com/DLR-RM/stable-baselines3/issues/1694 "
                "and documentation for more information: https://stable-baselines3.readthedocs.io/en/master/guide/vec_envs.html#vecenv-api-vs-gym-api"
            )

        obs_tensor, vectorized_env = self.obs_to_tensor(observation)

        with th.no_grad():
            actions = self._predict(obs_tensor, deterministic=deterministic, noise=action_noise, knn_callback=knn_callback, time_steps=time_steps, env=env)
        # Convert to numpy, and reshape to the original action shape
        actions = actions.cpu().numpy().reshape((-1, *self.action_space.shape))  # type: ignore[misc]

        if isinstance(self.action_space, spaces.Box):
            if self.squash_output:
                # Rescale to proper domain when using squashing
                actions = self.unscale_action(actions)  # type: ignore[assignment, arg-type]
            else:
                # Actions could be on arbitrary scale, so clip the actions to avoid
                # out of bound error (e.g. if sampling from a Gaussian distribution)
                actions = np.clip(actions, self.action_space.low, self.action_space.high)  # type: ignore[assignment, arg-type]

        # Remove batch dimension if needed
        if not vectorized_env:
            assert isinstance(actions, np.ndarray)
            actions = actions.squeeze(axis=0)

        return actions, state  # type: ignore[return-value]

    def _predict(self, observation: PyTorchObs, deterministic: bool = False, noise: Optional[th.Tensor] = None, knn_callback: Optional[Callable] = None, time_steps: Optional[List[int]] = None, env=None) -> th.Tensor:
        assert len(observation.shape) == 2, observation.shape

        if not deterministic: # condition needed to avoid updating exploration rate during evaluation
            exploration_rate = self.exploration_rate if isinstance(self.exploration_rate, (int, float)) else self.exploration_rate()

            assert 0 <= exploration_rate <= 1, exploration_rate

        if not deterministic and np.random.rand() < exploration_rate: # code adapted from dqn
            n_batch = observation.shape[0]
            action = None

            if self.action_space.__str__() == "ActionBoxSampleFromList":
                action_sampling_strategy = env.get_attr("action_sampling_strategy")
                assert n_batch == len(action_sampling_strategy) # n_envs

                assert len(set(action_sampling_strategy)) == 1, action_sampling_strategy

                action_sampling_strategy = action_sampling_strategy[0]

                if action_sampling_strategy == "none":
                    action = []

                    for n_env in range(n_batch):
                        data = env.get_attr("data", n_env)[0]
                        translation_candidate = env.get_attr("translation_candidate", n_env)[0]
                        src_translation_candidate = data[translation_candidate][0]
                        result = self.action_space.sample(src_translation_candidate=src_translation_candidate)

                        action.append(result)

            if action is None:
                action = [self.action_space.sample() for _ in range(n_batch)]

            if isinstance(action[0], np.ndarray):
                action = np.array(action) # list to array to avoid torch warning

            action = th.tensor(action)

            gym.logger.error("wasd3: random action: %s: %s", action.shape, action)
        else:
            if noise is not None and not isinstance(noise, th.Tensor):
                noise = th.tensor(noise).to(self.device)

            action = self._predict_conf(observation=observation, deterministic=deterministic, actor=self.actor, critic=lambda o, a, **kwargs: (self.critic.q1_forward(o, a, **kwargs),), training=False, actor_noise=noise, actor_clamp=True,
                                        knn_callback=knn_callback, time_steps=time_steps)

        return action

    def _predict_conf(self, observation: PyTorchObs, deterministic: bool = False, actor: Actor = None, critic: ContinuousCritic = None, actor_noise: th.Tensor = None, actor_clamp: bool = False,
                      training: bool = False, knn_callback: Optional[Callable] = None, time_steps: Optional[List[int]] = None) -> th.Tensor:
        if actor is None:
            actor = self.actor
        if critic is None:
            #critic = self.critic
            critic = lambda o, a, **kwargs: (self.critic.q1_forward(o, a, **kwargs),)

        if time_steps is not None:
            assert isinstance(time_steps, list)
            assert all([isinstance(t, int) for t in time_steps])

            model_kwargs = {"model_kwargs": {"step_embedding_idxs": time_steps}}
        else:
            model_kwargs = {}

        #gym.logger.error("wasd10.1 %s %s %s", observation.shape, observation, np.isnan(observation.detach().cpu().numpy()).any(axis=len(observation.shape) - 1).sum())

        actor_is_transformer = self.features_extractor_class == TransformerExtractor

        assert len(observation.shape) == 2, f"Observation shape was expected to contain 2 elements, but got {len(observation.shape)}"

        if actor_is_transformer:
            #assert observation.shape[-1] % self.actor_input_size == 0, f"Observation shape[-1] was expected to be multiple of {self.actor_input_size}, but got {observation.shape[-1]}"
            pass
        else:
            assert observation.shape[-1] == self.actor_input_size, f"Observation shape[-1] was expected to be {self.actor_input_size}, but got {observation.shape[-1]}"

        batch_size = observation.shape[0]
        proto_action = actor(observation, **model_kwargs) # (batch_size, [n_embeddings,] action_space)

        #gym.logger.error("wasd13 %s %s %s", proto_action.shape, proto_action, np.isnan(proto_action.detach().cpu().numpy()).any(axis=len(proto_action.shape) - 1).sum())

        assert len(observation.shape) == 2, f"Observation shape was expected to contain 2 elements, but got {len(observation.shape)}"

        if len(observation.shape) == 3:
            assert actor_is_transformer

            observation = observation.reshape((observation.shape[0], observation.shape[1] * observation.shape[2]))

        #gym.logger.error("wasd10.2 %s %s %s", observation.shape, observation, np.isnan(observation.detach().cpu().numpy()).any(axis=len(observation.shape) - 1).sum())

        if not self.wolpertinger_disable_actor and actor_noise is not None:
            # TD3-related
            proto_action = proto_action + actor_noise
        if actor_clamp:
            # TD3-related
            proto_action = proto_action.clamp(-1, 1)

        #gym.logger.error("wasd10.3 %s %s %s", proto_action.shape, proto_action, np.isnan(proto_action.detach().cpu().numpy()).any(axis=len(proto_action.shape) - 1).sum())

        assert len(proto_action.shape) == 2, f"Proto action shape was expected to contain 2 elements, but got {len(proto_action.shape)}"
        assert proto_action.shape[0] == batch_size, f"Proto action shape[0] was expected to be {batch_size}, but got {proto_action.shape[0]}"
        assert proto_action.shape[1] == self.actor_output_size, f"Proto action shape[1] was expected to be {self.actor_output_size}, but got {proto_action.shape[1]}"

        _knn_callback = knn_callback if knn_callback is not None else (self.callback_retrieve_knn_training if training else self.callback_retrieve_knn)
        knn = _knn_callback(proto_action.detach().cpu().numpy(), self.k, observations=observation) # (batch_size, <=k, action_space)

        if not self.wolpertinger_disable_actor and actor_is_transformer:
            token_representations = observation[:,actor.action_dim:] # remove action representation from observation

            if self.features_extractor_class == TransformerExtractor:
                token_representations = token_representations.reshape(observation.shape[0], -1, actor.features_extractor.transformer.initial_dim)
            else:
                token_representations = token_representations.reshape(observation.shape[0], -1, actor.mu[0].initial_dim)

            is_zero_vector = (token_representations == 0).all(axis=-1)
            used_tokens = token_representations.shape[1] - is_zero_vector.sum(axis=1)
            used_tokens = used_tokens.detach().cpu()
        else:
            used_tokens = -1

        if not training:
            #global asd
            gym.logger.error("wasd0 (%s) (sum abs_sum): %s (used: %s): %s",
                             "training" if training else "inference", observation.detach().cpu().shape, used_tokens if actor_is_transformer else None, observation.detach().cpu())
            gym.logger.error("wasd1 (%s) (sum abs_sum): %s (%s %s): %s",
                             "training" if training else "inference", proto_action.detach().cpu().shape, th.sum(proto_action, dim=1).detach().cpu(), th.sum(th.abs(proto_action), dim=1).detach().cpu(), proto_action.detach().cpu())

            #asd.append(proto_action.detach().cpu().squeeze(0).numpy())

            #np.save(f"./proto_actions.npy", np.array(asd))
            #gym.logger.error("wasd100: %d", len(asd))


        if not isinstance(knn, th.Tensor):
            #knn = th.tensor(knn).to(self.device)
            knn = th.tensor(knn).cpu()

        assert len(knn.shape) == 3, f"kNN shape was expected to contain 3 elements, but got {len(knn.shape)}"
        assert knn.shape[0] == batch_size, f"kNN shape[0] was expected to be {batch_size}, but got {knn.shape[0]}"
        assert knn.shape[1] <= self.k if not self.knn_percentage else True, f"kNN shape[1] was expected to be <={self.k}, but got {knn.shape[1]}"
        assert knn.shape[2] == self.actor_output_size, f"kNN shape[2] was expected to be {self.actor_output_size}, but got {knn.shape[2]}"

        _k = knn.shape[1]
        partial_result = []
#        _features = None

        assert self.add_all_knn_to_batch > 0, self.add_all_knn_to_batch

        #gym.logger.error("wasd141: observation and knn shape: %s %s", observation.shape, knn.shape)

        all_idxs = list(range(0, _k, self.add_all_knn_to_batch))

        assert all_idxs[0] == 0, all_idxs

        if self.add_all_knn_to_batch > 1 and _k > 1:
            if len(all_idxs) > 1:
                assert all_idxs[1] == self.add_all_knn_to_batch, all_idxs
                assert all_idxs[1] > 1, all_idxs

#            all_idxs.insert(1, 1) # process a single knn first to initialize _features

#            assert all_idxs[1] == 1, all_idxs

        all_idxs.append(_k) # end index

        #gym.logger.error("wasd142: all_idxs: %s", all_idxs)

        #gym.logger.info("wasd 562.3: datetime before for loop: %s", datetime.datetime.now())

        # Process neighbours in batches to reduce memory consumption
        for idx in range(len(all_idxs) - 1):
            start_idx = all_idxs[idx]
            #end_idx = min(start_idx + self.add_all_knn_to_batch, _k)
            end_idx = all_idxs[idx + 1]
            current_batch_size = end_idx - start_idx
            actual_batch_size = current_batch_size * batch_size

            # observation: (batch_size, observation_space)
            # knn: (batch_size, <=k, action_space)
            _knn = th.cat(tuple([knn[::,knn_idx] for knn_idx in range(start_idx, end_idx)]), dim=0).to(self.device) # (actual_batch_size, action_space)
            _observation = th.tile(observation, (current_batch_size, 1)).to(self.device) # (actual_batch_size, observation_space)

            #if _knn.shape[1] > 1:
            #    assert th.allclose(_knn[:,0], _knn[:,1])
            #    assert th.allclose(_knn[:,0], _knn[:,-1])

            #gym.logger.error("wasd141: _observation and _knn shape: %s %s", _observation.shape, _knn.shape)

            assert len(_observation.shape) == 2, f"_observation shape was expected to contain 2 elements, but got {len(_observation.shape)}"
            assert len(_knn.shape) == 2, f"_knn shape was expected to contain 2 elements, but got {len(_knn.shape)}"
            assert _observation.shape == (actual_batch_size, observation.shape[1]), f"_observation shape was expected to be ({actual_batch_size}, {observation.shape[1]}), but got {_observation.shape}"
            assert _knn.shape[0] == _observation.shape[0], f"_knn shape[0] was expected to be {_observation.shape[0]}, but got {_knn.shape[0]}"

            #gym.logger.error("wasd10.4 %s %s %s", _observation.shape, _observation, np.isnan(_observation.detach().cpu().numpy()).any(axis=len(_observation.shape) - 1).sum())

#            if _features is not None:
#                assert _features.shape[0] == batch_size, f"_features shape[0] was expected to be {batch_size}, but got {_features.shape[0]}"
#
#                _features = th.tile(_features, (current_batch_size, 1)).to(self.device) # (actual_batch_size, observation_space)
#
#                assert _features.shape[0] == actual_batch_size, f"_features shape[0] was expected to be {actual_batch_size}, but got {_features.shape[0]}"

            if time_steps is not None:
                _model_kwargs = {"model_kwargs": {"step_embedding_idxs": list([q for w in [time_steps for _ in range(current_batch_size)] for q in w])}}

                assert len(_model_kwargs["model_kwargs"]["step_embedding_idxs"]) == actual_batch_size, f"_model_kwargs['model_kwargs']['step_embedding_idxs'] length was expected to be {actual_batch_size}, but got {len(_model_kwargs['model_kwargs']['step_embedding_idxs'])}"
            else:
                _model_kwargs = {}

            with th.no_grad():
#                critic_output = critic(_observation, _knn, return_features=True, _features=_features, **model_kwargs)
                critic_output = critic(_observation, _knn, **_model_kwargs)

            assert isinstance(critic_output, tuple), f"Expected critic output to be a tuple, but got {type(critic_output)}"
            assert len(critic_output) == 1, f"Expected 1, but got {len(critic_output)}"
#            assert isinstance(critic_output[0], tuple), f"Expected critic output[0] to be a tuple, but got {type(critic_output[0])}"
#            assert len(critic_output[0]) == 2, f"Expected 2, but got {len(critic_output[0])}"
#
#            critic_output, features = critic_output[0]
#            critic_output = (critic_output,)

            assert isinstance(critic_output[0], th.Tensor), f"Expected critic output[0] to be a Tensor, but got {type(critic_output[0])}"

#            if start_idx == 0:
#                assert features.shape[0] == batch_size, f"Features shape[0] was expected to be {batch_size}, but got {features.shape[0]}"
#            else:
#                assert th.equal(features[:batch_size,:], _features[:batch_size,:]), f"Features from the critic are not consistent across different knn neighbours: {features} vs {_features}"
#
#            #_features = features[:actual_batch_size,:]
#            _features = features[:batch_size,:]
#
#            assert len(critic_output) == 1, f"Expected 1, but got {len(critic_output)}"

            critic_output = th.cat(critic_output, dim=1)

            #gym.logger.error("wasd141: critic_output2: %s %s", critic_output.shape, critic_output.detach().cpu())
            #critic_output, _= th.min(critic_output, dim=1, keepdim=True)

            assert len(critic_output.shape) == 2
            assert critic_output.shape[0] == actual_batch_size, critic_output.shape
            assert critic_output.shape[1] == 1, critic_output.shape # Q(s,a)

            critic_output = critic_output.view((current_batch_size, batch_size, 1))
            critic_output = critic_output.permute(1, 0, 2) # (batch_size, current_batch_size, 1)

            #gym.logger.error("wasd141: critic_output3: %s %s", critic_output.shape, critic_output.detach().cpu())

            #partial_result.append(critic_output.detach().cpu())
            partial_result.append(critic_output.detach())

        #gym.logger.info("wasd 562.3: datetime after for loop: %s", datetime.datetime.now())

        partial_result = th.cat(partial_result, dim=1) # (batch_size, <=k, 1)

        #gym.logger.error("wasd141: result: %s %s", partial_result.shape, partial_result.detach().cpu())

        assert len(partial_result.shape) == 3
        assert partial_result.shape[0] == batch_size, f"{partial_result.shape} vs {batch_size}"
        assert partial_result.shape[1] == _k, f"{partial_result.shape} vs {_k}" # neighbours
        assert partial_result.shape[2] == 1, f"{partial_result.shape} vs 1" # Q(s,a)

        #partial_result = partial_result.reshape((batch_size, _k, 1))
        critic_output = partial_result

#        if self.add_all_knn_to_batch:
#            # observation: (batch_size, action_space)
#            # knn: (batch_size, <=k, action_space)
#            #_knn = knn.reshape((_k * batch_size, self.actor_output_size))
#            _knn = th.cat(tuple([knn[::,knn_idx] for knn_idx in range(_k)]), dim=0).to(self.device)
#            _observation = th.tile(observation, (_k, 1)).to(self.device)
#
#            #gym.logger.error("wasd10.4 %s %s %s", _observation.shape, _observation, np.isnan(_observation.detach().cpu().numpy()).any(axis=len(_observation.shape) - 1).sum())
#
#            critic_output = critic(_observation, _knn)
#            critic_output = th.cat(critic_output, dim=1)
#            #critic_output, _= th.min(critic_output, dim=1, keepdim=True)
#
#            assert len(critic_output.shape) == 2
#            assert critic_output.shape[0] == _k * batch_size, critic_output.shape
#            assert critic_output.shape[1] == 1, critic_output.shape # Q(s,a)
#
#            critic_output = critic_output.reshape((batch_size, _k, 1))
#        else:
#            # Process each neighbour individually
#            partial_result = []
#            _features = None
#
#            for knn_idx in range(_k):
#                _knn = knn[:,knn_idx] # Get each neighbour (the knn_idx th) for each observation
#
#                assert _knn.shape == (batch_size, self.actor_output_size), f"_knn shape was expected to be ({batch_size}, {self.actor_output_size}), but got {_knn.shape}"
#
#                critic_output = critic(observation, _knn, return_features=True, _features=_features) # Evaluate observations with each knn. The output is a tuple for the N critic networks
#
#                assert isinstance(critic_output, tuple), f"Expected critic output to be a tuple, but got {type(critic_output)}"
#                assert len(critic_output) == 1, f"Expected 1, but got {len(critic_output)}"
#                assert isinstance(critic_output[0], tuple), f"Expected critic output[0] to be a tuple, but got {type(critic_output[0])}"
#                assert len(critic_output[0]) == 2, f"Expected 2, but got {len(critic_output[0])}"
#
#                critic_output, features = critic_output[0]
#                critic_output = (critic_output,)
#
#                if knn_idx > 0:
#                    assert th.equal(features, _features), f"Features from the critic are not consistent across different knn neighbours: {features} vs {_features}"
#
#                _features = features
#
#                #assert len(critic_output) == self.n_critics, f"Expected {self.n_critics} critics, but got {len(critic_output)}"
#                assert len(critic_output) == 1, f"Expected 1, but got {len(critic_output)}"
#
#                critic_output = th.cat(critic_output, dim=1)
#                #expected_shape = (batch_size, self.n_critics)
#                expected_shape = (batch_size, 1) # the critic should always return a single value
#
#                assert critic_output.shape == expected_shape, f"Expected shape was {expected_shape}, but got {critic_output.shape}"
#
#                #critic_output, _= th.min(critic_output, dim=1, keepdim=True) # Take min Q(s,a) from all critics (TD3)
#
#                assert len(critic_output.shape) == 2, f"critic shape was expected to contain 2 elements, but got {len(critic_output.shape)}"
#                assert critic_output.shape[0] == batch_size, f"critic shape[0] was expected to be {batch_size}, but got {critic_output.shape[0]}"
#                assert critic_output.shape[1] == 1, f"critic shape[1] was expected to be 1, but got {critic_output.shape[1]}"
#
#                partial_result.append(critic_output.detach().cpu().numpy())
#
#            partial_result = np.array(partial_result) # (<=k, batch_size, 1)
#            partial_result = th.from_numpy(partial_result)
#
#            assert len(partial_result.shape) == 3
#            assert partial_result.shape[0] == _k # neighbours
#            assert partial_result.shape[1] == batch_size
#            assert partial_result.shape[2] == 1 # Q(s,a)
#
#            partial_result = partial_result.reshape((batch_size, _k, 1))
#            critic_output = partial_result

        if not training:
            gym.logger.error("wasd2.1 (%s) (sum abs_sum): %s (%s %s): %s",
                             "training" if training else "inference", critic_output.detach().cpu().shape, th.sum(critic_output, dim=1).detach().cpu(), th.sum(th.abs(critic_output), dim=1).detach().cpu(), critic_output.detach().cpu().squeeze(-1))

            mean = th.mean(critic_output.detach().cpu(), dim=1)
            std = th.std(critic_output.detach().cpu(), dim=1)
            max_value = th.max(critic_output.detach().cpu(), dim=1)[0]

            gym.logger.error("wasd2.2 (%s) (max - mean: mean: std): %s: %s: %s",
                             "training" if training else "inference", max_value - mean, mean, std)

        if not deterministic and self.apply_rws_inference:
            result = self.roulette_wheel_selection(knn, critic_output)
            result = th.tensor(result).to(self.device)
        else:
            result = []
            #argmax_idx = np.argmax(critic_output.detach().cpu().numpy(), axis=1)
            argmax_idx = th.argmax(critic_output.detach(), dim=1).cpu().numpy()
            v, i = th.max(critic_output.detach(), dim=1)

            assert len(argmax_idx.shape) == 2
            assert argmax_idx.shape[0] == batch_size
            assert argmax_idx.shape[1] == 1

            for idx, _argmax_idx in enumerate(argmax_idx):
                _argmax_idx = _argmax_idx[0]
                #_argmax_value = critic_output.detach().cpu().numpy()[idx,_argmax_idx,0].item()
                _argmax_value = critic_output.detach()[idx,_argmax_idx,0].item()

                assert _argmax_idx == i[idx].item(), f"{_argmax_idx} vs {i[idx].item()}"
                assert _argmax_value == v[idx].item(), f"{_argmax_value} vs {v[idx].item()}"

                if isinstance(self.k, int):
                    assert _argmax_idx < self.k

                if not training:
                    gym.logger.error("wasd4 (%s): %s %s %s", "training" if training else "inference", idx, _argmax_idx, _argmax_value)

                result.append(knn[idx][_argmax_idx])

            result = th.stack(result, dim=0).to(self.device)

            assert len(result.shape) == 2
            assert result.shape[0] == batch_size
            assert result.shape[1] == knn.shape[2]

        #if not training:
        #    gym.logger.error("wasd3: %s (%s; %s): %s", result.shape, th.sum(result, dim=1).detach().cpu(), th.sum(th.abs(result), dim=1).detach().cpu(), result)

        return result

class CnnPolicy(TD3Policy):
    """
    Policy class (with both actor and critic) for TD3.

    :param observation_space: Observation space
    :param action_space: Action space
    :param lr_schedule: Learning rate schedule (could be constant)
    :param net_arch: The specification of the policy and value networks.
    :param activation_fn: Activation function
    :param features_extractor_class: Features extractor to use.
    :param features_extractor_kwargs: Keyword arguments
        to pass to the features extractor.
    :param normalize_images: Whether to normalize images or not,
         dividing by 255.0 (True by default)
    :param optimizer_class: The optimizer to use,
        ``th.optim.Adam`` by default
    :param optimizer_kwargs: Additional keyword arguments,
        excluding the learning rate, to pass to the optimizer
    :param n_critics: Number of critic networks to create.
    :param share_features_extractor: Whether to share or not the features extractor
        between the actor and the critic (this saves computation time)
    """

    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        lr_schedule: Schedule,
        net_arch: Optional[Union[List[int], Dict[str, List[int]]]] = None,
        activation_fn: Type[nn.Module] = nn.ReLU,
        features_extractor_class: Type[BaseFeaturesExtractor] = NatureCNN,
        features_extractor_kwargs: Optional[Dict[str, Any]] = None,
        normalize_images: bool = True,
        optimizer_class: Type[th.optim.Optimizer] = th.optim.Adam,
        optimizer_kwargs: Optional[Dict[str, Any]] = None,
        n_critics: int = 2,
        share_features_extractor: bool = False,
    ):
        super().__init__(
            observation_space,
            action_space,
            lr_schedule,
            net_arch,
            activation_fn,
            features_extractor_class,
            features_extractor_kwargs,
            normalize_images,
            optimizer_class,
            optimizer_kwargs,
            n_critics,
            share_features_extractor,
        )


class MultiInputPolicy(TD3Policy):
    """
    Policy class (with both actor and critic) for TD3 to be used with Dict observation spaces.

    :param observation_space: Observation space
    :param action_space: Action space
    :param lr_schedule: Learning rate schedule (could be constant)
    :param net_arch: The specification of the policy and value networks.
    :param activation_fn: Activation function
    :param features_extractor_class: Features extractor to use.
    :param features_extractor_kwargs: Keyword arguments
        to pass to the features extractor.
    :param normalize_images: Whether to normalize images or not,
         dividing by 255.0 (True by default)
    :param optimizer_class: The optimizer to use,
        ``th.optim.Adam`` by default
    :param optimizer_kwargs: Additional keyword arguments,
        excluding the learning rate, to pass to the optimizer
    :param n_critics: Number of critic networks to create.
    :param share_features_extractor: Whether to share or not the features extractor
        between the actor and the critic (this saves computation time)
    """

    def __init__(
        self,
        observation_space: spaces.Dict,
        action_space: spaces.Box,
        lr_schedule: Schedule,
        net_arch: Optional[Union[List[int], Dict[str, List[int]]]] = None,
        activation_fn: Type[nn.Module] = nn.ReLU,
        features_extractor_class: Type[BaseFeaturesExtractor] = CombinedExtractor,
        features_extractor_kwargs: Optional[Dict[str, Any]] = None,
        normalize_images: bool = True,
        optimizer_class: Type[th.optim.Optimizer] = th.optim.Adam,
        optimizer_kwargs: Optional[Dict[str, Any]] = None,
        n_critics: int = 2,
        share_features_extractor: bool = False,
    ):
        super().__init__(
            observation_space,
            action_space,
            lr_schedule,
            net_arch,
            activation_fn,
            features_extractor_class,
            features_extractor_kwargs,
            normalize_images,
            optimizer_class,
            optimizer_kwargs,
            n_critics,
            share_features_extractor,
        )
