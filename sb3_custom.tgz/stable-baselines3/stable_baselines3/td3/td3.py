from typing import Any, ClassVar, Dict, List, Optional, Tuple, Type, TypeVar, Union, Callable

import numpy as np
import torch as th
from gymnasium import spaces
from torch.nn import functional as F
import gymnasium as gym
import datetime

from stable_baselines3.common.buffers import ReplayBuffer
from stable_baselines3.common.noise import ActionNoise
from stable_baselines3.common.off_policy_algorithm import OffPolicyAlgorithm
from stable_baselines3.common.policies import BasePolicy, ContinuousCritic
from stable_baselines3.common.type_aliases import GymEnv, MaybeCallback, Schedule
from stable_baselines3.common.utils import get_parameters_by_name, polyak_update, explained_variance
from stable_baselines3.td3.policies import Actor, CnnPolicy, MlpPolicy, MultiInputPolicy, TD3Policy, WolpertingerPolicy
from stable_baselines3.common.torch_layers import TransformerExtractor
from stable_baselines3.common.vec_env import VecEnv

SelfTD3 = TypeVar("SelfTD3", bound="TD3")

# "Deep Reinforcement Learning in Parameterized Action Space" (https://arxiv.org/abs/1511.04143)
class InvertGrad(th.autograd.Function):
    @staticmethod
    def forward(ctx, input, min_val=-1.0, max_val=1.0):
        min_t = th.as_tensor(min_val, dtype=input.dtype, device=input.device)
        max_t = th.as_tensor(max_val, dtype=input.dtype, device=input.device)

        clamped = input.clamp(min_t.item(), max_t.item())

        ctx.save_for_backward(clamped)
        ctx.min_val = float(min_t.item())
        ctx.max_val = float(max_t.item())

        #return input
        return clamped.clamp(min_val, max_val)

    @staticmethod
    def backward(ctx, grad_output):
        clamped, = ctx.saved_tensors
        min_val, max_val = ctx.min_val, ctx.max_val

        # Calculate the distance to the bounds
        dist_min = (clamped - min_val) / (max_val - min_val)
        dist_max = (max_val - clamped) / (max_val - min_val)

        # Choose scale based on sign of gradient (direction of update)
        #scale = th.min(dist_min, dist_max)
        positive_mask = grad_output > 0
        scale = th.where(positive_mask, dist_max, dist_min)
        grad_input = grad_output * scale

        return grad_input, None, None

class TD3(OffPolicyAlgorithm):
    """
    Twin Delayed DDPG (TD3)
    Addressing Function Approximation Error in Actor-Critic Methods.

    Original implementation: https://github.com/sfujim/TD3
    Paper: https://arxiv.org/abs/1802.09477
    Introduction to TD3: https://spinningup.openai.com/en/latest/algorithms/td3.html

    :param policy: The policy model to use (MlpPolicy, CnnPolicy, ...)
    :param env: The environment to learn from (if registered in Gym, can be str)
    :param learning_rate: learning rate for adam optimizer,
        the same learning rate will be used for all networks (Q-Values, Actor and Value function)
        it can be a function of the current progress remaining (from 1 to 0)
    :param buffer_size: size of the replay buffer
    :param learning_starts: how many steps of the model to collect transitions for before learning starts
    :param batch_size: Minibatch size for each gradient update
    :param tau: the soft update coefficient ("Polyak update", between 0 and 1)
    :param gamma: the discount factor
    :param train_freq: Update the model every ``train_freq`` steps. Alternatively pass a tuple of frequency and unit
        like ``(5, "step")`` or ``(2, "episode")``.
    :param gradient_steps: How many gradient steps to do after each rollout (see ``train_freq``)
        Set to ``-1`` means to do as many gradient steps as steps done in the environment
        during the rollout.
    :param action_noise: the action noise type (None by default), this can help
        for hard exploration problem. Cf common.noise for the different action noise type.
    :param replay_buffer_class: Replay buffer class to use (for instance ``HerReplayBuffer``).
        If ``None``, it will be automatically selected.
    :param replay_buffer_kwargs: Keyword arguments to pass to the replay buffer on creation.
    :param optimize_memory_usage: Enable a memory efficient variant of the replay buffer
        at a cost of more complexity.
        See https://github.com/DLR-RM/stable-baselines3/issues/37#issuecomment-637501195
    :param policy_delay: Policy and target networks will only be updated once every policy_delay steps
        per training steps. The Q values will be updated policy_delay more often (update every training step).
    :param target_policy_noise: Standard deviation of Gaussian noise added to target policy
        (smoothing noise)
    :param target_noise_clip: Limit for absolute value of target policy smoothing noise.
    :param stats_window_size: Window size for the rollout logging, specifying the number of episodes to average
        the reported success rate, mean episode length, and mean reward over
    :param tensorboard_log: the log location for tensorboard (if None, no logging)
    :param policy_kwargs: additional arguments to be passed to the policy on creation
    :param verbose: Verbosity level: 0 for no output, 1 for info messages (such as device or wrappers used), 2 for
        debug messages
    :param seed: Seed for the pseudo random generators
    :param device: Device (cpu, cuda, ...) on which the code should be run.
        Setting it to auto, the code will be run on the GPU if possible.
    :param _init_setup_model: Whether or not to build the network at the creation of the instance
    """

    policy_aliases: ClassVar[Dict[str, Type[BasePolicy]]] = {
        "MlpPolicy": MlpPolicy,
        "CnnPolicy": CnnPolicy,
        "MultiInputPolicy": MultiInputPolicy,
        "WolpertingerPolicy": WolpertingerPolicy,
    }
    policy: TD3Policy
    actor: Actor
    actor_target: Actor
    critic: ContinuousCritic
    critic_target: ContinuousCritic

    def __init__(
        self,
        policy: Union[str, Type[TD3Policy]],
        env: Union[GymEnv, str],
        learning_rate: Union[float, Schedule] = 1e-3,
        buffer_size: int = 1_000_000,  # 1e6
        learning_starts: int = 100,
        batch_size: int = 256,
        tau: float = 0.005,
        gamma: float = 0.99,
        train_freq: Union[int, Tuple[int, str]] = 1,
        gradient_steps: int = 1,
        action_noise: Optional[ActionNoise] = None,
        replay_buffer_class: Optional[Type[ReplayBuffer]] = None,
        replay_buffer_kwargs: Optional[Dict[str, Any]] = None,
        optimize_memory_usage: bool = False,
        n_steps: int = 1,
        policy_delay: int = 2,
        target_policy_noise: float = 0.2,
        target_noise_clip: float = 0.5,
        stats_window_size: int = 100,
        tensorboard_log: Optional[str] = None,
        policy_kwargs: Optional[Dict[str, Any]] = None,
        verbose: int = 0,
        seed: Optional[int] = None,
        device: Union[th.device, str] = "auto",
        _init_setup_model: bool = True,
        max_grad_norm: Optional[float] = None,
        lambda_penalty: float = 0.0,
        invert_grad: bool = False,
        wolpertinger_target_policy_actor_noise: float = 0.2,
        wolpertinger_target_actor_noise_clip: float = 0.5,
        wolpertinger_add_noise_after_knn: bool = True,
    ):
        super().__init__(
            policy,
            env,
            learning_rate,
            buffer_size,
            learning_starts,
            batch_size,
            tau,
            gamma,
            train_freq,
            gradient_steps,
            action_noise=action_noise,
            replay_buffer_class=replay_buffer_class,
            replay_buffer_kwargs=replay_buffer_kwargs,
            policy_kwargs=policy_kwargs,
            stats_window_size=stats_window_size,
            tensorboard_log=tensorboard_log,
            verbose=verbose,
            device=device,
            seed=seed,
            sde_support=False,
            optimize_memory_usage=optimize_memory_usage,
            n_steps=n_steps,
            supported_action_spaces=(spaces.Box,),
            support_multi_env=True,
        )

        self.replay_buffer_kwargs = replay_buffer_kwargs
        self.policy_delay = policy_delay
        self.target_noise_clip = target_noise_clip
        self.target_policy_noise = target_policy_noise
        self.max_grad_norm = max_grad_norm
        self.lambda_penalty = lambda_penalty
        self.invert_grad = invert_grad
        self.wolpertinger_target_policy_actor_noise = wolpertinger_target_policy_actor_noise
        self.wolpertinger_target_actor_noise_clip = wolpertinger_target_actor_noise_clip
        self.wolpertinger_add_noise_after_knn = wolpertinger_add_noise_after_knn

        gym.logger.error("invert_grad: %s", self.invert_grad)

        if _init_setup_model:
            self._setup_model()

    def _setup_model(self) -> None:
        super()._setup_model()
        self._create_aliases()
        # Running mean and running var
        self.actor_batch_norm_stats = get_parameters_by_name(self.actor, ["running_"])
        self.critic_batch_norm_stats = get_parameters_by_name(self.critic, ["running_"])
        self.actor_batch_norm_stats_target = get_parameters_by_name(self.actor_target, ["running_"])
        self.critic_batch_norm_stats_target = get_parameters_by_name(self.critic_target, ["running_"])

    def _create_aliases(self) -> None:
        self.actor = self.policy.actor
        self.actor_target = self.policy.actor_target
        self.critic = self.policy.critic
        self.critic_target = self.policy.critic_target

    def train(self, gradient_steps: int, batch_size: int = 100) -> None:
        is_wolpertinger_policy = isinstance(self.policy, WolpertingerPolicy) # Training changes a bit

        # Switch to train mode (this affects batch norm / dropout)
        self.policy.set_training_mode(True)

        # Update learning rate according to lr schedule
        self._update_learning_rate([(self.actor.optimizer, self.policy.actor_lr_schedule), (self.critic.optimizer, self.policy.critic_lr_schedule)])

        #gym.logger.info("wasd 562: datetime before training: %s", datetime.datetime.now())

        actor_losses, critic_losses = [], []
        for gradient_step_idx in range(gradient_steps):
            self._n_updates += 1
            # Sample replay buffer
            replay_data = self.replay_buffer.sample(batch_size, env=self._vec_normalize_env)  # type: ignore[union-attr]
            # For n-step replay, discount factor is gamma**n_steps (when no early termination)
            discounts = replay_data.discounts if replay_data.discounts is not None else self.gamma
            time_steps = replay_data.time_steps if replay_data.time_steps is not None else None

            #gym.logger.error("wasd56.1: replay_data.time_steps: %s", time_steps)

            if time_steps is not None:
                assert is_wolpertinger_policy
                assert isinstance(time_steps, th.Tensor)

                time_steps = time_steps.cpu().detach().tolist()

                assert isinstance(time_steps, list)
                assert all([isinstance(t, int) for t in time_steps])

                time_steps_next = [time_step + 1 for time_step in time_steps]
                model_kwargs = {"model_kwargs": {"step_embedding_idxs": time_steps}}
                model_next_kwargs = {"model_kwargs": {"step_embedding_idxs": time_steps_next}}
            else:
                time_steps_next = None
                model_kwargs = {}
                model_next_kwargs = {}

            #gym.logger.error("wasd30: %s: %s", replay_data.actions.shape, replay_data.actions)

            with th.no_grad():
                # Select action according to policy and add clipped noise
                noise = replay_data.actions.clone().data.normal_(0, self.target_policy_noise)
                noise = noise.clamp(-self.target_noise_clip, self.target_noise_clip)

                #gym.logger.error("wasd40: %s (%s; %s)", noise.shape, th.sum(noise).detach().cpu().item(), th.sum(th.abs(noise)).detach().cpu().item())

                #assert (replay_data.actions >= -1).all() and (replay_data.actions <= 1).all().cpu().item(), "asd!!!"

                # Compute the next Q-values: min over all critics targets
                if is_wolpertinger_policy:
                    actor_noise = replay_data.actions.clone().data.normal_(0, self.wolpertinger_target_policy_actor_noise)
                    actor_noise = actor_noise.clamp(-self.wolpertinger_target_actor_noise_clip, self.wolpertinger_target_actor_noise_clip)

                    #gym.logger.info("wasd 562.2: datetime before _predict_conf #%d: %s", gradient_step_idx, datetime.datetime.now())

                    # pi_theta'
                    # here both networks are target networks (from the paper: "The parameter theta represents both the parameters of the action generation element in theta_pi and of the critic in theta_Q")
                    #next_actions = self.policy._predict_conf(replay_data.next_observations, actor=self.actor_target, critic=self.critic_target, actor_noise=noise, actor_clamp=True, training=True)
                    #next_actions = self.policy._predict_conf(replay_data.next_observations, actor=self.actor_target, critic=self.critic_target, training=True)
                    #next_actions = self.policy._predict_conf(replay_data.next_observations, actor=self.actor_target, critic=lambda o, a: (self.critic.q1_forward(o, a),), actor_noise=noise, actor_clamp=True, training=True)
                    next_actions = self.policy._predict_conf(replay_data.next_observations, actor=self.actor_target, critic=lambda o, a, **kwargs: (self.critic_target.q1_forward(o, a, **kwargs),), actor_noise=actor_noise, actor_clamp=True, training=True, time_steps=time_steps_next)

                    #gym.logger.info("wasd 562.2: datetime after _predict_conf #%d: %s", gradient_step_idx, datetime.datetime.now())

                    if self.wolpertinger_add_noise_after_knn:
                        # As long as the discrete actions representations have some meaninful relation among them, adding noise may help improve generalization and robustness
                        next_actions = (next_actions + noise).clamp(-1, 1)
                else:
                    next_actions = self.actor_target(replay_data.next_observations, **model_next_kwargs)
                    next_actions = (next_actions + noise).clamp(-1, 1)

                #next_actions = (next_actions + noise).clamp(-1, 1)

                # theta_Q'
                next_q_values = th.cat(self.critic_target(replay_data.next_observations, next_actions, **model_next_kwargs), dim=1)
                next_q_values, _ = th.min(next_q_values, dim=1, keepdim=True)

                #assert not np.isnan(replay_data.rewards).any(), "NaN found in rewards"

                # y_i
                target_q_values = replay_data.rewards + (1 - replay_data.dones) * discounts * next_q_values

            #gym.logger.error("wasd61.1: Rewards: %s", replay_data.rewards)
            #gym.logger.error("wasd61.2: Dones: %s", replay_data.dones)
            #gym.logger.error("wasd61.3: time_steps: %s", time_steps)

            #assert np.allclose(replay_data.dones.detach().cpu().numpy().flatten(), np.ones_like(replay_data.dones.detach().cpu().numpy().flatten())), f"Expected all dones to be 1 (monte-carlo update), but got {replay_data.dones.detach().cpu().numpy().flatten()}"

            # Get current Q-values estimates for each critic network
            # theta_Q
            current_q_values = self.critic(replay_data.observations, replay_data.actions, **model_kwargs)

            #if self._n_updates % 1000 == 0:
            if False and self._n_updates % 50 == 0:
                # Explained variance for diagnostics, to indicate how well the critic is fitting the data
                y_pred = []
                y_true = []
                n_accumulated_data = 10

                y_pred.append(current_q_values[0].detach().cpu().numpy().flatten())
                y_true.append(target_q_values.detach().cpu().numpy().flatten())

                for _ in range(n_accumulated_data - 1): # accumulate data
                    tmp_replay_data = self.replay_buffer.sample(batch_size, env=self._vec_normalize_env)  # type: ignore[union-attr]
                    tmp_discounts = tmp_replay_data.discounts if tmp_replay_data.discounts is not None else self.gamma
                    tmp_time_steps = tmp_replay_data.time_steps if tmp_replay_data.time_steps is not None else None

                    #assert np.allclose(tmp_replay_data.dones.detach().cpu().numpy().flatten(), np.ones_like(tmp_replay_data.dones.detach().cpu().numpy().flatten())), f"Expected all dones to be 1 (monte-carlo update), but got {tmp_replay_data.dones.detach().cpu().numpy().flatten()}"

                    if tmp_time_steps is not None:
                        assert is_wolpertinger_policy
                        assert isinstance(tmp_time_steps, th.Tensor)

                        tmp_time_steps = tmp_time_steps.cpu().detach().tolist()

                        assert isinstance(tmp_time_steps, list)
                        assert all([isinstance(t, int) for t in tmp_time_steps])

                        tmp_time_steps_next = [tmp_time_step + 1 for tmp_time_step in tmp_time_steps]
                        tmp_model_kwargs = {"model_kwargs": {"step_embedding_idxs": tmp_time_steps}}
                        tmp_model_next_kwargs = {"model_kwargs": {"step_embedding_idxs": tmp_time_steps_next}}
                    else:
                        tmp_time_steps_next = None
                        tmp_model_kwargs = {}
                        tmp_model_next_kwargs = {}

                    with th.no_grad():
                        tmp_noise = tmp_replay_data.actions.clone().data.normal_(0, self.target_policy_noise)
                        tmp_noise = tmp_noise.clamp(-self.target_noise_clip, self.target_noise_clip)

                        if is_wolpertinger_policy:
                            tmp_actor_noise = tmp_replay_data.actions.clone().data.normal_(0, self.wolpertinger_target_policy_actor_noise)
                            tmp_actor_noise = tmp_actor_noise.clamp(-self.wolpertinger_target_actor_noise_clip, self.wolpertinger_target_actor_noise_clip)
                            tmp_next_actions = self.policy._predict_conf(tmp_replay_data.next_observations, actor=self.actor_target, critic=lambda o, a, **kwargs: (self.critic_target.q1_forward(o, a, **kwargs),), actor_noise=tmp_actor_noise, actor_clamp=True, training=True, time_steps=tmp_time_steps_next)

                            if self.wolpertinger_add_noise_after_knn:
                                tmp_next_actions = (tmp_next_actions + tmp_noise).clamp(-1, 1)
                        else:
                            tmp_next_actions = self.actor_target(tmp_replay_data.next_observations, **tmp_model_next_kwargs)
                            tmp_next_actions = (tmp_next_actions + tmp_noise).clamp(-1, 1)

                        tmp_next_q_values = th.cat(self.critic_target(tmp_replay_data.next_observations, tmp_next_actions, **tmp_model_next_kwargs), dim=1)
                        tmp_next_q_values, _ = th.min(tmp_next_q_values, dim=1, keepdim=True)
                        tmp_target_q_values = tmp_replay_data.rewards + (1 - tmp_replay_data.dones) * tmp_discounts * tmp_next_q_values
                        tmp_current_q_values = self.critic(tmp_replay_data.observations, tmp_replay_data.actions, **tmp_model_kwargs)
                        tmp_y_pred = tmp_current_q_values[0].detach().cpu().numpy().flatten()
                        tmp_y_true = tmp_target_q_values.detach().cpu().numpy().flatten()

                    y_pred.append(tmp_y_pred)
                    y_true.append(tmp_y_true)

                y_pred = np.concatenate(y_pred)
                y_true = np.concatenate(y_true)
                explained_var = explained_variance(y_pred, y_true)

                gym.logger.info("wasd 62: %d: Explained variance: %s (%d elements)", self._n_updates, explained_var, len(y_true))
                #gym.logger.info("wasd 63.1: %d: y_pred: %s", self._n_updates, y_pred)
                #gym.logger.info("wasd 63.2: %d: y_true: %s", self._n_updates, y_true)
                #gym.logger.info("wasd 63.3: %d: time_steps: %s", self._n_updates, tmp_time_steps)
                #gym.logger.info("wasd 63.4: %d: dones: %s", self._n_updates, tmp_replay_data.dones)

            # Compute critic loss
            #critic_loss = sum(F.mse_loss(current_q, target_q_values) for current_q in current_q_values)
            critic_loss = sum(F.smooth_l1_loss(current_q, target_q_values) for current_q in current_q_values) # return values should be [-1, 1]
            assert isinstance(critic_loss, th.Tensor)
            critic_losses.append(critic_loss.item())

            # Optimize the critics
            self.critic.optimizer.zero_grad()
            critic_loss.backward()

            if self.max_grad_norm is not None:
                th.nn.utils.clip_grad_norm_(self.critic.parameters(), self.max_grad_norm)

            self.critic.optimizer.step()

            if False and (hasattr(self.critic, "cls_token") or isinstance(self.critic.features_extractor, TransformerExtractor)):
                if hasattr(self.critic, "cls_token"):
                    cls_token = self.critic.cls_token
                else:
                    cls_token = self.critic.features_extractor.transformer.cls_token

                cls_token_grad_norm = cls_token.grad.norm().item()

                gym.logger.error("wasd321: cls_token_grad_norm: %s", cls_token_grad_norm)

                assert cls_token_grad_norm > 0, f"No gradient for cls_token (critic): {cls_token_grad_norm}"

            # Delayed policy updates
            if self._n_updates % self.policy_delay == 0:
                # Compute actor loss
                actor_actions = self.actor(replay_data.observations, **model_kwargs)

                if self.invert_grad:
                    actor_actions = InvertGrad.apply(actor_actions, -1.0, 1.0)

                action_norm_penalty = (actor_actions ** 2).sum(dim=1).mean()
                actor_loss = -self.critic.q1_forward(replay_data.observations, actor_actions, **model_kwargs).mean()
                actor_loss += self.lambda_penalty * action_norm_penalty
                actor_losses.append(actor_loss.item())

                # Optimize the actor
                self.actor.optimizer.zero_grad()
                actor_loss.backward()

                if False and not self.policy.wolpertinger_disable_actor and (hasattr(self.actor, "cls_token") or isinstance(self.actor.features_extractor, TransformerExtractor)):
                    if hasattr(self.actor, "cls_token"):
                        cls_token = self.actor.cls_token
                    else:
                        cls_token = self.actor.features_extractor.transformer.cls_token

                    cls_token_grad_norm = cls_token.grad.norm().item()

                    gym.logger.error("wasd322: cls_token_grad_norm: %s", cls_token_grad_norm)

                    if not self.policy.wolpertinger_disable_actor:
                        assert cls_token_grad_norm > 0, f"No gradient for cls_token (actor): {cls_token_grad_norm}"
                    else:
                        assert cls_token_grad_norm == 0, f"Gradient for cls_token (actor): {cls_token_grad_norm}"

                if self.max_grad_norm is not None:
                    th.nn.utils.clip_grad_norm_(self.actor.parameters(), self.max_grad_norm)

                self.actor.optimizer.step()

                polyak_update(self.critic.parameters(), self.critic_target.parameters(), self.tau)
                polyak_update(self.actor.parameters(), self.actor_target.parameters(), self.tau)
                # Copy running stats, see GH issue #996
                polyak_update(self.critic_batch_norm_stats, self.critic_batch_norm_stats_target, 1.0)
                polyak_update(self.actor_batch_norm_stats, self.actor_batch_norm_stats_target, 1.0)

            #gym.logger.info("wasd 562: datetime after training #%d: %s", gradient_step_idx, datetime.datetime.now())

        self.logger.record("train/n_updates", self._n_updates, exclude="tensorboard")
        if len(actor_losses) > 0:
            self.logger.record("train/actor_loss", np.mean(actor_losses))
        self.logger.record("train/critic_loss", np.mean(critic_losses))

        best_reward_seen_list = self.env.get_attr("best_reward_seen")

        assert isinstance(best_reward_seen_list, list), type(best_reward_seen_list)
        assert len(best_reward_seen_list) == self.n_envs, f"{len(best_reward_seen_list)} vs {self.n_envs}"

        best_reward_seen = {}

        for _best_reward_seen in best_reward_seen_list:
            assert isinstance(_best_reward_seen, dict), type(_best_reward_seen)

            for k, v in _best_reward_seen.items():
                if k not in best_reward_seen:
                    best_reward_seen[k] = v

                best_reward_seen[k] = max(best_reward_seen[k], v)

        reward_mean_all_episodes = sum(list(best_reward_seen.values())) / len(best_reward_seen) if len(best_reward_seen) > 0 else -100.0
        gym.logger.info("wasd 512: Best mean reward so far across all episodes (%d elements seen): %s", len(best_reward_seen), reward_mean_all_episodes)

    def learn(
        self: SelfTD3,
        total_timesteps: int,
        callback: MaybeCallback = None,
        log_interval: int = 4,
        tb_log_name: str = "TD3",
        reset_num_timesteps: bool = True,
        progress_bar: bool = False,
    ) -> SelfTD3:
        return super().learn(
            total_timesteps=total_timesteps,
            callback=callback,
            log_interval=log_interval,
            tb_log_name=tb_log_name,
            reset_num_timesteps=reset_num_timesteps,
            progress_bar=progress_bar,
        )

    def _excluded_save_params(self) -> List[str]:
        return super()._excluded_save_params() + ["actor", "critic", "actor_target", "critic_target"]  # noqa: RUF005

    def _get_torch_save_params(self) -> Tuple[List[str], List[str]]:
        state_dicts = ["policy", "actor.optimizer", "critic.optimizer"]
        return state_dicts, []

    def _sample_action(
        self,
        learning_starts: int,
        action_noise: Optional[ActionNoise] = None,
        n_envs: int = 1,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Code from OffPolicyAlgorithm with modifications for WolpertingerPolicy.
        """
        is_wolpertinger_policy = isinstance(self.policy, WolpertingerPolicy)

        # Select action randomly or according to policy
        if self.num_timesteps < learning_starts and not (self.use_sde and self.use_sde_at_warmup):
            # Warmup phase
            need_sample = True

            #gym.logger.error("wasd100: %s", self.action_space.__str__())

            if self.action_space.__str__() == "ActionBoxSampleFromList":
                action_sampling_strategy = self.env.get_attr("action_sampling_strategy")

                assert len(set(action_sampling_strategy)) == 1, action_sampling_strategy

                action_sampling_strategy = action_sampling_strategy[0]

                if action_sampling_strategy == "bm25":
                    need_sample = False
                    unscaled_action = []

                    for n_env in range(n_envs):
                        time_step = self.env.get_attr("time_step", n_env)[0]
                        data = self.env.get_attr("data", n_env)[0]
                        custom_env_id = self.env.get_attr("custom_env_id", n_env)[0]
                        translation_candidate = self.env.get_attr("translation_candidate", n_env)[0]
                        src_translation_candidate = data[translation_candidate][0]
                        result = self.action_space.sample_bm25(time_step=time_step, src_translation_candidate=src_translation_candidate, custom_env_id=custom_env_id)

                        unscaled_action.append(result)

                    unscaled_action = np.array(unscaled_action)
                elif action_sampling_strategy == "none":
                    need_sample = False
                    unscaled_action = []

                    for n_env in range(n_envs):
                        data = self.env.get_attr("data", n_env)[0]
                        translation_candidate = self.env.get_attr("translation_candidate", n_env)[0]
                        src_translation_candidate = data[translation_candidate][0]
                        result = self.action_space.sample(src_translation_candidate=src_translation_candidate)

                        unscaled_action.append(result)

                    unscaled_action = np.array(unscaled_action)

            if need_sample:
                need_sample = False
                unscaled_action = np.array([self.action_space.sample() for _ in range(n_envs)])
        else:
            # Note: when using continuous actions,
            # we assume that the policy uses tanh to scale the action
            # We use non-deterministic action in the case of SAC, for TD3, it does not matter
            assert self._last_obs is not None, "self._last_obs was not set"

            if is_wolpertinger_policy and action_noise is not None:
                unscaled_action, _ = self.predict(self._last_obs, deterministic=False, action_noise=action_noise())
            else:
                unscaled_action, _ = self.predict(self._last_obs, deterministic=False)

        # Rescale the action from [low, high] to [-1, 1]
        if isinstance(self.action_space, spaces.Box):
            scaled_action = self.policy.scale_action(unscaled_action)

            # Add noise to the action (improve exploration)
            if action_noise is not None and not is_wolpertinger_policy:
                scaled_action = np.clip(scaled_action + action_noise(), -1, 1)

            # We store the scaled action in the buffer
            buffer_action = scaled_action
            action = self.policy.unscale_action(scaled_action)
        else:
            # Discrete case, no need to normalize or clip
            buffer_action = unscaled_action
            action = buffer_action
        return action, buffer_action

    def predict(
        self,
        observation: Union[np.ndarray, Dict[str, np.ndarray]],
        state: Optional[Tuple[np.ndarray, ...]] = None,
        episode_start: Optional[np.ndarray] = None,
        deterministic: bool = False,
        action_noise: Optional[ActionNoise] = None,
        knn_callback: Optional[Callable] = None,
        env_instance: Optional[VecEnv] = None,
    ) -> Tuple[np.ndarray, Optional[Tuple[np.ndarray, ...]]]:
        """
        Code from BaseAlgorithm with modifications for WolpertingerPolicy.
        """
        is_wolpertinger_policy = isinstance(self.policy, WolpertingerPolicy)

        if is_wolpertinger_policy:
            env_instance = self.env if env_instance is None else env_instance
            time_steps = None

            if isinstance(self.replay_buffer_kwargs, dict) and self.replay_buffer_kwargs.get("process_time_steps", False):
                if isinstance(env_instance, VecEnv):
                    time_steps = env_instance.get_attr("time_step")

                    assert len(time_steps) == self.n_envs, f"{len(time_steps)}: {time_steps}"
                else:
                    assert hasattr(env_instance, "time_step"), type(env_instance)

                    time_steps = [env_instance.time_step]

                assert isinstance(time_steps, list), f"{type(time_steps)}: {time_steps}"

            #time_steps = [t - 1 for t in time_steps] # [0, max_icl_examples - 1]

            #if len(set(time_steps)) == 1 and time_steps[0] == -1:
            #    time_steps = [0 for _ in time_steps] # first time step, which is not correctly aligned in the environment... in the next step, time step will be 2, and 1 after the subtraction, so it will be aligned with the model embeddings

            return self.policy.predict(observation, state, episode_start, deterministic, action_noise=action_noise, knn_callback=knn_callback, time_steps=time_steps, env=self.env)

        return self.policy.predict(observation, state, episode_start, deterministic)
