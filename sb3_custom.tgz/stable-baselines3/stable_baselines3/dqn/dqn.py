import warnings
from typing import Any, ClassVar, Dict, List, Optional, Tuple, Type, TypeVar, Union

import numpy as np
import torch as th
from gymnasium import spaces
from torch.nn import functional as F
import gymnasium as gym

from stable_baselines3.common.buffers import ReplayBuffer
from stable_baselines3.common.off_policy_algorithm import OffPolicyAlgorithm
from stable_baselines3.common.policies import BasePolicy
from stable_baselines3.common.type_aliases import GymEnv, MaybeCallback, Schedule
from stable_baselines3.common.utils import get_linear_fn, get_parameters_by_name, polyak_update
from stable_baselines3.dqn.policies import CnnPolicy, DQNPolicy, MlpPolicy, MultiInputPolicy, QNetwork
from stable_baselines3.common.noise import ActionNoise
from stable_baselines3.common.vec_env import VecEnv

SelfDQN = TypeVar("SelfDQN", bound="DQN")


class DQN(OffPolicyAlgorithm):
    """
    Deep Q-Network (DQN)

    Paper: https://arxiv.org/abs/1312.5602, https://www.nature.com/articles/nature14236
    Default hyperparameters are taken from the Nature paper,
    except for the optimizer and learning rate that were taken from Stable Baselines defaults.

    :param policy: The policy model to use (MlpPolicy, CnnPolicy, ...)
    :param env: The environment to learn from (if registered in Gym, can be str)
    :param learning_rate: The learning rate, it can be a function
        of the current progress remaining (from 1 to 0)
    :param buffer_size: size of the replay buffer
    :param learning_starts: how many steps of the model to collect transitions for before learning starts
    :param batch_size: Minibatch size for each gradient update
    :param tau: the soft update coefficient ("Polyak update", between 0 and 1) default 1 for hard update
    :param gamma: the discount factor
    :param train_freq: Update the model every ``train_freq`` steps. Alternatively pass a tuple of frequency and unit
        like ``(5, "step")`` or ``(2, "episode")``.
    :param gradient_steps: How many gradient steps to do after each rollout (see ``train_freq``)
        Set to ``-1`` means to do as many gradient steps as steps done in the environment
        during the rollout.
    :param replay_buffer_class: Replay buffer class to use (for instance ``HerReplayBuffer``).
        If ``None``, it will be automatically selected.
    :param replay_buffer_kwargs: Keyword arguments to pass to the replay buffer on creation.
    :param optimize_memory_usage: Enable a memory efficient variant of the replay buffer
        at a cost of more complexity.
        See https://github.com/DLR-RM/stable-baselines3/issues/37#issuecomment-637501195
    :param target_update_interval: update the target network every ``target_update_interval``
        environment steps.
    :param exploration_fraction: fraction of entire training period over which the exploration rate is reduced
    :param exploration_initial_eps: initial value of random action probability
    :param exploration_final_eps: final value of random action probability
    :param max_grad_norm: The maximum value for the gradient clipping
    :param stats_window_size: Window size for the rollout logging, specifying the number of episodes to average
        the reported success rate, mean episode length, and mean reward over
    :param tensorboard_log: the log location for tensorboard (if None, no logging)
    :param policy_kwargs: additional arguments to be passed to the policy on creation
    :param verbose: Verbosity level: 0 for no output, 1 for info messages (such as device or wrappers used), 2 for
        debug messages
    :param seed: Seed for the pseudo random generators
    :param device: Device (cpu, cuda, ...) on which the code should be run.
        Setting it to auto, the code will be run on the GPU if possible.
    :param _init_setup_model: Whether or not to build the network at the creation of the instance
    """

    policy_aliases: ClassVar[Dict[str, Type[BasePolicy]]] = {
        "MlpPolicy": MlpPolicy,
        "CnnPolicy": CnnPolicy,
        "MultiInputPolicy": MultiInputPolicy,
    }
    # Linear schedule will be defined in `_setup_model()`
    exploration_schedule: Schedule
    q_net: QNetwork
    q_net_target: QNetwork
    policy: DQNPolicy

    def __init__(
        self,
        policy: Union[str, Type[DQNPolicy]],
        env: Union[GymEnv, str],
        learning_rate: Union[float, Schedule] = 1e-4,
        buffer_size: int = 1_000_000,  # 1e6
        learning_starts: int = 100,
        batch_size: int = 32,
        tau: float = 1.0,
        gamma: float = 0.99,
        train_freq: Union[int, Tuple[int, str]] = 4,
        gradient_steps: int = 1,
        replay_buffer_class: Optional[Type[ReplayBuffer]] = None,
        replay_buffer_kwargs: Optional[Dict[str, Any]] = None,
        optimize_memory_usage: bool = False,
        target_update_interval: int = 10000,
        exploration_fraction: float = 0.1,
        exploration_initial_eps: float = 1.0,
        exploration_final_eps: float = 0.05,
        max_grad_norm: float = 10,
        stats_window_size: int = 100,
        tensorboard_log: Optional[str] = None,
        policy_kwargs: Optional[Dict[str, Any]] = None,
        verbose: int = 0,
        seed: Optional[int] = None,
        device: Union[th.device, str] = "auto",
        _init_setup_model: bool = True,
        n_steps: int = 1,
        exploration_rate_custom: bool = None,
        avoid_overlapping_action: bool = False,
    ) -> None:
        super().__init__(
            policy,
            env,
            learning_rate,
            buffer_size,
            learning_starts,
            batch_size,
            tau,
            gamma,
            train_freq,
            gradient_steps,
            action_noise=None,  # No action noise
            replay_buffer_class=replay_buffer_class,
            replay_buffer_kwargs=replay_buffer_kwargs,
            policy_kwargs=policy_kwargs,
            stats_window_size=stats_window_size,
            tensorboard_log=tensorboard_log,
            verbose=verbose,
            device=device,
            seed=seed,
            sde_support=False,
            optimize_memory_usage=optimize_memory_usage,
            n_steps=n_steps,
            supported_action_spaces=(spaces.Discrete,),
            support_multi_env=True,
        )

        self.exploration_initial_eps = exploration_initial_eps
        self.exploration_final_eps = exploration_final_eps
        self.exploration_fraction = exploration_fraction
        self.target_update_interval = target_update_interval
        # For updating the target network with multiple envs:
        self._n_calls = 0
        self.max_grad_norm = max_grad_norm
        # "epsilon" for the epsilon-greedy exploration
        self.exploration_rate = 0.0
        self.exploration_rate_custom = exploration_rate_custom
        self.avoid_overlapping_action = avoid_overlapping_action

        if _init_setup_model:
            self._setup_model()

    def _setup_model(self) -> None:
        super()._setup_model()
        self._create_aliases()
        # Copy running stats, see GH issue #996
        self.batch_norm_stats = get_parameters_by_name(self.q_net, ["running_"])
        self.batch_norm_stats_target = get_parameters_by_name(self.q_net_target, ["running_"])

        if self.exploration_rate_custom is not None:
            self.exploration_schedule = self.exploration_rate_custom
        else:
            self.exploration_schedule = get_linear_fn(
                self.exploration_initial_eps,
                self.exploration_final_eps,
                self.exploration_fraction,
            )

        if self.n_envs > 1:
            if self.n_envs > self.target_update_interval:
                warnings.warn(
                    "The number of environments used is greater than the target network "
                    f"update interval ({self.n_envs} > {self.target_update_interval}), "
                    "therefore the target network will be updated after each call to env.step() "
                    f"which corresponds to {self.n_envs} steps."
                )

    def _create_aliases(self) -> None:
        self.q_net = self.policy.q_net
        self.q_net_target = self.policy.q_net_target

    def _on_step(self) -> None:
        """
        Update the exploration rate and target network if needed.
        This method is called in ``collect_rollouts()`` after each step in the environment.
        """
        self._n_calls += 1
        # Account for multiple environments
        # each call to step() corresponds to n_envs transitions
#        if self._n_calls % max(self.target_update_interval // self.n_envs, 1) == 0:
#            polyak_update(self.q_net.parameters(), self.q_net_target.parameters(), self.tau)
#            # Copy running stats, see GH issue #996
#            polyak_update(self.batch_norm_stats, self.batch_norm_stats_target, 1.0)
#
#        self.exploration_rate = self.exploration_schedule(self._current_progress_remaining)
#        self.logger.record("rollout/exploration_rate", self.exploration_rate)

    def train(self, gradient_steps: int, batch_size: int = 100) -> None:
        # Switch to train mode (this affects batch norm / dropout)
        self.policy.set_training_mode(True)
        # Update learning rate according to schedule
        #self._update_learning_rate(self.policy.optimizer)
        self._update_learning_rate([(self.policy.optimizer, self.policy.lr_schedule)])

        losses = []
        for _ in range(gradient_steps):
            self._n_updates += 1
            # Sample replay buffer
            replay_data = self.replay_buffer.sample(batch_size, env=self._vec_normalize_env)  # type: ignore[union-attr]
            time_steps = replay_data.time_steps if replay_data.time_steps is not None else None

            if time_steps is not None:
                assert isinstance(time_steps, th.Tensor)

                time_steps = time_steps.cpu().detach().tolist()

                assert isinstance(time_steps, list)
                assert all([isinstance(t, int) for t in time_steps])

                time_steps_next = [time_step + 1 for time_step in time_steps]
                model_kwargs = {"model_kwargs": {"step_embedding_idxs": time_steps}}
                model_next_kwargs = {"model_kwargs": {"step_embedding_idxs": time_steps_next}}
            else:
                time_steps_next = None
                model_kwargs = {}
                model_next_kwargs = {}

            with th.no_grad():
                # Compute the next Q-values using the target network
                next_q_values = self.q_net_target(replay_data.next_observations, **model_next_kwargs)
                # Follow greedy policy: use the one with the highest value
                next_q_values, _ = next_q_values.max(dim=1)
                # Avoid potential broadcast issue
                next_q_values = next_q_values.reshape(-1, 1)
                # 1-step TD target
                target_q_values = replay_data.rewards + (1 - replay_data.dones) * self.gamma * next_q_values

            # Get current Q-values estimates
            current_q_values = self.q_net(replay_data.observations, **model_kwargs)

            # Retrieve the q-values for the actions from the replay buffer
            current_q_values = th.gather(current_q_values, dim=1, index=replay_data.actions.long())

            # Compute Huber loss (less sensitive to outliers)
            loss = F.smooth_l1_loss(current_q_values, target_q_values)
            losses.append(loss.item())

            # Optimize the policy
            self.policy.optimizer.zero_grad()
            loss.backward()
            # Clip gradient norm
            th.nn.utils.clip_grad_norm_(self.policy.parameters(), self.max_grad_norm)
            self.policy.optimizer.step()

            if self._n_updates % self.target_update_interval == 0:
                polyak_update(self.q_net.parameters(), self.q_net_target.parameters(), self.tau)
                # Copy running stats, see GH issue #996
                polyak_update(self.batch_norm_stats, self.batch_norm_stats_target, 1.0)

        # Increase update counter
        #self._n_updates += gradient_steps

        self.logger.record("train/n_updates", self._n_updates, exclude="tensorboard")
        self.logger.record("train/loss", np.mean(losses))

        best_reward_seen_list = self.env.get_attr("best_reward_seen")

        assert isinstance(best_reward_seen_list, list), type(best_reward_seen_list)
        assert len(best_reward_seen_list) == self.n_envs, f"{len(best_reward_seen_list)} vs {self.n_envs}"

        best_reward_seen = {}

        for _best_reward_seen in best_reward_seen_list:
            assert isinstance(_best_reward_seen, dict), type(_best_reward_seen)

            for k, v in _best_reward_seen.items():
                if k not in best_reward_seen:
                    best_reward_seen[k] = v

                best_reward_seen[k] = max(best_reward_seen[k], v)

        reward_mean_all_episodes = sum(list(best_reward_seen.values())) / len(best_reward_seen) if len(best_reward_seen) > 0 else -100.0
        gym.logger.info("wasd 512: Best mean reward so far across all episodes (%d elements seen): %s", len(best_reward_seen), reward_mean_all_episodes)

    def predict(
        self,
        observation: Union[np.ndarray, Dict[str, np.ndarray]],
        state: Optional[Tuple[np.ndarray, ...]] = None,
        episode_start: Optional[np.ndarray] = None,
        deterministic: bool = False,
        env_instance = None,
    ) -> Tuple[np.ndarray, Optional[Tuple[np.ndarray, ...]]]:
        """
        Overrides the base_class predict function to include epsilon-greedy exploration.

        :param observation: the input observation
        :param state: The last states (can be None, used in recurrent policies)
        :param episode_start: The last masks (can be None, used in recurrent policies)
        :param deterministic: Whether or not to return deterministic actions.
        :return: the model's action and the next state
            (used in recurrent policies)
        """
        env_instance = self.env if env_instance is None else env_instance

        if not deterministic:
            self.exploration_rate = self.exploration_schedule(self._current_progress_remaining)
            self.logger.record("rollout/exploration_rate", self.exploration_rate)

        if not deterministic and np.random.rand() < self.exploration_rate:
            if self.policy.is_vectorized_observation(observation):
                if isinstance(observation, dict):
                    n_batch = observation[next(iter(observation.keys()))].shape[0]
                else:
                    n_batch = observation.shape[0]
                #action = np.array([self.action_space.sample() for _ in range(n_batch)])
            else:
                n_batch = 1
                #action = np.array(self.action_space.sample())

            if self.avoid_overlapping_action:
                action = []
                icl_example_representation_icl2idx = env_instance.get_attr("icl_example_representation_icl2idx", 0)[0]
                icl_example_representation_icl2idx = [k.split('\t')[0] for k in icl_example_representation_icl2idx.keys()]

                for n_env in range(n_batch):
                    data = env_instance.get_attr("data", n_env)[0]
                    translation_candidate = env_instance.get_attr("translation_candidate", n_env)[0]
                    src_translation_candidate = data[translation_candidate][0]
                    result_idx = self.action_space.sample()

                    assert isinstance(result_idx, np.integer), f"Expected discrete action, got {result}"

                    result = icl_example_representation_icl2idx[result_idx]

                    while result == src_translation_candidate:
                        #gym.logger.error("wasd42: Removing overlapping (sampling): %s", result_idx)

                        result_idx = self.action_space.sample()
                        result = icl_example_representation_icl2idx[result_idx]

                    action.append(result_idx)

                action = np.array(action)

                #gym.logger.error("wasd43: %s", action)
            else:
                action = np.array([self.action_space.sample() for _ in range(n_batch)])

            assert action.shape == (n_batch,), f"Expected action shape ({n_batch},), got {action.shape}"
        else:
            time_steps = None

            if isinstance(self.replay_buffer_kwargs, dict) and self.replay_buffer_kwargs.get("process_time_steps", False):
                if isinstance(env_instance, VecEnv):
                    time_steps = env_instance.get_attr("time_step")

                    assert len(time_steps) == self.n_envs, f"{len(time_steps)}: {time_steps}"
                else:
                    assert hasattr(env_instance, "time_step"), type(env_instance)

                    time_steps = [env_instance.time_step]

                assert isinstance(time_steps, list), f"{type(time_steps)}: {time_steps}"

            #gym.logger.error("wasd 65: DQN.predict: time_steps: %s", time_steps)

            action, state = self.policy.predict(observation, state, episode_start, deterministic, time_steps=time_steps, inference=True)

        return action, state

    def learn(
        self: SelfDQN,
        total_timesteps: int,
        callback: MaybeCallback = None,
        log_interval: int = 4,
        tb_log_name: str = "DQN",
        reset_num_timesteps: bool = True,
        progress_bar: bool = False,
    ) -> SelfDQN:
        return super().learn(
            total_timesteps=total_timesteps,
            callback=callback,
            log_interval=log_interval,
            tb_log_name=tb_log_name,
            reset_num_timesteps=reset_num_timesteps,
            progress_bar=progress_bar,
        )

    def _excluded_save_params(self) -> List[str]:
        return [*super()._excluded_save_params(), "q_net", "q_net_target"]

    def _get_torch_save_params(self) -> Tuple[List[str], List[str]]:
        state_dicts = ["policy", "policy.optimizer"]

        return state_dicts, []

    def _sample_action(
        self,
        learning_starts: int,
        action_noise: Optional[ActionNoise] = None,
        n_envs: int = 1,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Code from OffPolicyAlgorithm with modifications.
        """
        # Select action randomly or according to policy
        if self.num_timesteps < learning_starts and not (self.use_sde and self.use_sde_at_warmup):
            # Warmup phase
            if self.avoid_overlapping_action:
                unscaled_action = []
                icl_example_representation_icl2idx = self.env.get_attr("icl_example_representation_icl2idx", 0)[0]
                icl_example_representation_icl2idx = [k.split('\t')[0] for k in icl_example_representation_icl2idx.keys()]

                for n_env in range(n_envs):
                    data = self.env.get_attr("data", n_env)[0]
                    translation_candidate = self.env.get_attr("translation_candidate", n_env)[0]
                    src_translation_candidate = data[translation_candidate][0]
                    result_idx = self.action_space.sample()

                    assert isinstance(result_idx, np.integer), f"Expected discrete action, got {result}"

                    result = icl_example_representation_icl2idx[result_idx]

                    while result == src_translation_candidate:
                        #gym.logger.error("wasd44: Removing overlapping (sampling): %s", result_idx)

                        result_idx = self.action_space.sample()
                        result = icl_example_representation_icl2idx[result_idx]

                    unscaled_action.append(result_idx)

                unscaled_action = np.array(unscaled_action)

                #gym.logger.error("wasd45: %s", unscaled_action)
            else:
                unscaled_action = np.array([self.action_space.sample() for _ in range(n_envs)])

            assert unscaled_action.shape == (n_envs,), f"Expected action shape ({n_envs},), got {unscaled_action.shape}"
        else:
            # Note: when using continuous actions,
            # we assume that the policy uses tanh to scale the action
            # We use non-deterministic action in the case of SAC, for TD3, it does not matter
            assert self._last_obs is not None, "self._last_obs was not set"
            unscaled_action, _ = self.predict(self._last_obs, deterministic=False)

        # Rescale the action from [low, high] to [-1, 1]
        if isinstance(self.action_space, spaces.Box):
            scaled_action = self.policy.scale_action(unscaled_action)

            # Add noise to the action (improve exploration)
            if action_noise is not None:
                scaled_action = np.clip(scaled_action + action_noise(), -1, 1)

            # We store the scaled action in the buffer
            buffer_action = scaled_action
            action = self.policy.unscale_action(scaled_action)
        else:
            # Discrete case, no need to normalize or clip
            buffer_action = unscaled_action
            action = buffer_action
        return action, buffer_action
